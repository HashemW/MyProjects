/*Hashem Wahed, UID: 117960716, hwahed@grace.umd.edu*/

#include <stdio.h>
#include "document.h"
#include <string.h>
#include <sysexits.h>
#include <stdlib.h>
#include <ctype.h>

/* 
   If the name or doc given in the parameter are NULL, 
   failure is returned. Also,
   if the length of the name parameter is greater 
   than the max string size,
   failure is also returned. Else, it should be fine, 
   the number_of_paragraphs
   is set to 0 and the document's name is set to what is in 
   the parameter, finally, success is returned.
*/
int init_document(Document * doc, const char *name) {
   if (name == NULL || doc == NULL || strlen(name) > MAX_STR_SIZE) {
      return FAILURE;
   }
   doc->number_of_paragraphs = 0;
   strcpy(doc->name, name);
   return SUCCESS;
}

/*
  If the doc parameter is NULL failure is returned, 
  else the paragraphs are just set to 0 and success is returned.
*/
int reset_document(Document * doc) {
   if (doc == NULL) {
      return FAILURE;
   }
   doc->number_of_paragraphs = 0;
   return SUCCESS;
}

/*
  To print the document, we must go two layers 
  deep because of the nested
  structure. First we check if doc is null, 
  if it is failure is returned.
  We print the document name, the number 
  of paragraphs, and the loop
  begins. We first have the outer for loop 
  through the paragraphs,
  and the inner for loop for the 
  lines within each paragraph. We
  print each of those lines, and boom we are good.
*/
int print_document(Document * doc) {
   int paragraph_count, line_count, is_empty = 1;
   if (doc == NULL) {
      return FAILURE;
   }
   printf("Document name: \"%s\"\n", doc->name);
   printf("Number of Paragraphs: %d\n", doc->number_of_paragraphs);
   for (paragraph_count = 1; paragraph_count <= doc->number_of_paragraphs;
        paragraph_count++) {
      for (line_count = 1;
           line_count <= doc->paragraphs[paragraph_count].number_of_lines;
           line_count++) {
         if (strcmp(doc->paragraphs[paragraph_count].lines[line_count], "") ==
             0) {

         } else {
            printf("%s\n",
                   doc->paragraphs[paragraph_count].lines[line_count]);
            is_empty = 0;
         }
      }
      if (paragraph_count != doc->number_of_paragraphs && is_empty == 0) {
         printf("\n");
         is_empty = 1;
      }
   }
   return SUCCESS;
}

/*
  Start by checking the necessary requirements 
  for the parameters. Failure is
  returned if the parameters suck.
  1. doc cannot be null.
  2. The document cannot have the same amount as 
  MAX_PARAGRAPHS or more (somehow, idk).
  3. A paragraph cannot be added if it is 
  greater than the number of available paragraphs.
  Otherwise, the number of paragraphs
  is incremented and a specific paragraphs 
  number of lines is initialized
  to 0 to show there is a paragraph. Success is then returned.
*/
int add_paragraph_after(Document * doc, int paragraph_number) {
   int count;
   if (doc == NULL || doc->number_of_paragraphs >= MAX_PARAGRAPHS ||
       paragraph_number > doc->number_of_paragraphs) {
      return FAILURE;
   }
   doc->number_of_paragraphs++;
   if (paragraph_number < doc->number_of_paragraphs) {
      for (count = doc->number_of_paragraphs; count > paragraph_number;
           count--) {
         doc->paragraphs[count] = doc->paragraphs[count - 1];
      }
   }
   doc->paragraphs[paragraph_number + 1].number_of_lines = 0;
   return SUCCESS;
}

/*
  We start by checking if the necessary 
  conditions are met for the parameters,
  if they do not meet the conditions, failure is returned.
  1. doc cannot be null.
  2. A line cannot be addaded if line count 
  is greater or equal to MAX_PARAGRAPH_LINES.
  3. A paragraph cannot be added if it is greater 
  than the number of available paragraphs.
  4. The line number cannot be greater 
  than the number of available lines.
  5. new_line cannot be null
  To add a line,
  the number of lines within that 
  specific paragraph is incremented, and then
  the new_line string is put into 
  a new line in the paragraph. Then,
  success is returned.
*/
int add_line_after(Document * doc, int paragraph_number, int line_number,
                   const char *new_line) {
   int count;
   if (doc == NULL || paragraph_number > doc->number_of_paragraphs ||
       doc->paragraphs[paragraph_number].number_of_lines >=
       MAX_PARAGRAPH_LINES ||
       line_number > doc->paragraphs[paragraph_number].number_of_lines ||
       new_line == NULL) {
      return FAILURE;
   }
   /*
      This if statement is to see if the line is added in order or not.
      This is important because if the line is not added in order,
      then we will have to shift the lines up.
    */
   doc->paragraphs[paragraph_number].number_of_lines++;
   if (line_number != doc->paragraphs[paragraph_number].number_of_lines) {
      for (count = doc->paragraphs[paragraph_number].number_of_lines;
           count > line_number; count--) {
         strcpy(doc->paragraphs[paragraph_number].lines[count],
                doc->paragraphs[paragraph_number].lines[count - 1]);
      }
   }
   strcpy(doc->paragraphs[paragraph_number].lines[line_number + 1], new_line);

   return SUCCESS;
}

/*
  The parameters are checked if they are valid, 
  1. number_of_lines cannot be null.
  2. paragraph number cannot be greater than 
  the number of available paragraphs.
  3. doc cannot be null.
  if they are valid, the number_of_lines is set to the
  number of lines and success is returned.
*/
int get_number_lines_paragraph(Document * doc, int paragraph_number,
                               int *number_of_lines) {
   if (number_of_lines == NULL || doc == NULL ||
       paragraph_number > doc->number_of_paragraphs) {
      return FAILURE;
   }
   *number_of_lines = (doc->paragraphs[paragraph_number].number_of_lines);
   return SUCCESS;
}

/*
  To append a line, the parameters are checked for validity.
  1. doc cannot be null.
  2. A paragraph cannot be greater than the number of paragraphs available.
  3. A line number cannot be greater than/equal to max number of lines.
  4. new_line cannot be null
  Then, starting at 
  the first line, through the document until we find the correct paragraph
  number, when we do, the line is appended.
  Success is then returned.
*/
int append_line(Document * doc, int paragraph_number, const char *new_line) {
   int line_count;
   if (doc == NULL || paragraph_number > doc->number_of_paragraphs ||
       doc->paragraphs[paragraph_number].number_of_lines >=
       MAX_PARAGRAPH_LINES || new_line == NULL) {
      return FAILURE;
   }

   for (line_count = 0;
        line_count <= doc->paragraphs[paragraph_number].number_of_lines;
        line_count++) {
      if (line_count == doc->paragraphs[paragraph_number].number_of_lines) {
         add_line_after(doc, paragraph_number, line_count, new_line);
         break;
      }
   }
   return SUCCESS;
}

/*
  To remove a line, we check if the parameters are valid.
  1. doc cannot be null
  2. paragraph number cannot be greater than the available paragraphs.
  3. line number cannot be greater than the available lines.
  We go through a for loop then to essentially move down the array by 1 line
  by copying and pasting the lines 1 down.
  And then we decrement the number of lines.
  Success is returned afterwards.
*/
int remove_line(Document * doc, int paragraph_number, int line_number) {
   int count;
   if (doc == NULL || paragraph_number > doc->number_of_paragraphs ||
       line_number > doc->paragraphs[paragraph_number].number_of_lines) {
      return FAILURE;
   }
   for (count = line_number;
        count < doc->paragraphs[paragraph_number].number_of_lines; count++) {
      strcpy(doc->paragraphs[paragraph_number].lines[count],
             doc->paragraphs[paragraph_number].lines[count + 1]);
   }
   doc->paragraphs[paragraph_number].number_of_lines--;

   return SUCCESS;
}

/*
  Valid parameters:
  1. doc cannot be null
  2. data cannot be null
  3. data_lines cannot be 0
  The initial paragraph is added, and then a for loop is used to add the rest
  of the paragraphs, because "" in the document represents a paragraph.
  Then another for loop is went through to load the document line by line.
  Success is returned.
*/
int load_document(Document * doc, char data[][MAX_STR_SIZE + 1],
                  int data_lines) {

   int count, paragraph_count = 0, line_number = 0;
   if (doc == NULL || data == NULL || data_lines == 0) {
      return FAILURE;
   }
   /*
      Adding Paragraphs
    */
   add_paragraph_after(doc, paragraph_count);
   paragraph_count++;

   for (count = 0; count < data_lines; count++) {
      if (strcmp(data[count], "") == 0) {
         add_paragraph_after(doc, paragraph_count);
         paragraph_count++;
      }
   }
   /*
      Starting from the first paragraph, adding individual lines to document.
    */
   paragraph_count = 1;
   for (count = 0; count < data_lines; count++) {
      if (strcmp(data[count], "") == 0) {
         paragraph_count++;
         line_number = 0;
      } else {
         add_line_after(doc, paragraph_count, line_number, data[count]);
         line_number++;
      }
   }

   return SUCCESS;

}

/*
  This function is used in highlight_text, remove_text, and replace_text.
  When those methods find a character which is the same character as the
  starting letter of the text, this function is called to see if it is
  actually the text we are looking for. 
*/
int is_target(int pos, const char *target, char *src) {
   int target_length = strlen(target), count;
   /* 
      A for loop is went through to check the text letter by letter,
      if one character is wrong, false is returned.
    */
   for (count = 0; count < target_length; count++) {
      if (*(target + count) == *(src + pos)) {
         pos++;
         continue;
      } else {
         return 0;
      }
   }
   return 1;
}

/*
  This function is simply an addition to the remove_text method, there
  was just simply too much too write. This function does the tough
  lifting and string manipulation to remove the string.
*/
void remove_text_two(char *src, int first_index, int removal_length) {
   int str_count, src_length = strlen(src);
   /*
      This for loop moves the text back a 
      necessary amount (depending on the size
      of the text we are removing), overwriting 
      the text to be removed by copying
      the string back character by character. When 
      we finally hit a null character,
      we know our job is done because there is nothing left to copy.
    */
   for (str_count = first_index; str_count < MAX_STR_SIZE + 1; str_count++) {
      if (*(src + (str_count + removal_length)) == '\0') {
         break;
      }
      *(src + str_count) = *(src + (str_count + removal_length));
   }
   /*
      Now, we know everything was copied back 
      according to our previous for loop, but
      there are extra characters we don't need
      because we removed a text! So we just
      fill them in with null characters!
    */
   for (str_count = src_length - removal_length; str_count < MAX_STR_SIZE + 1;
        str_count++) {
      if (*(src + str_count) == '\0') {
         break;
      }
      *(src + str_count) = '\0';
   }
}

/*
  This function was created for two scenarios. 
  The general function it is to serve is the
  replace_text function. If the replacement text 
  to our text is of equal size or smaller,
  we use this function.
*/
void replace_text_with_smaller_replacement(char *src, const char *replacement,
                                           int first_index,
                                           int removal_length,
                                           int replacement_length) {
   int str_count, src_length = strlen(src), replacement_count = 0;
   /*
      First, we replace the characters we need to 
      replace, character by character.
    */
   for (str_count = first_index; str_count < first_index + replacement_length;
        str_count++) {
      *(src + str_count) = *(replacement + replacement_count);
      replacement++;
   }
   /*
      Here the for loop pushes back the string so 
      any extra characters are removed(if the replacement
      text is smaller than original), if the replacement 
      text is the same size as the original
      this for loop does not really do anything.
    */
   for (str_count = first_index + replacement_length;
        str_count < MAX_STR_SIZE + 1; str_count++) {
      if (*(src + (str_count)) == '\0') {
         break;
      }
      *(src + str_count) =
         *(src + (str_count + (removal_length - replacement_length)));
   }
   /*
      For any extra characters after pushing the 
      string back, they are set to the null char here.
    */
   for (str_count = src_length - removal_length + replacement_length + 1;
        str_count < MAX_STR_SIZE + 1; str_count++) {
      if (*(src + str_count) == '\0') {
         break;
      }
      *(src + str_count) = '\0';
   }
}

/*
  This function is meant for the replace_text 
  function, this function is utilised when 
  the replacement text is larger than the 
  source text. It manipulates the string and 
  replaces the text properly.
*/
void replace_text_with_bigger_replacement(char *src, const char *replacement,
                                          int first_index, int removal_length,
                                          int replacement_length) {
   int str_count, src_length = strlen(src), replacement_count = 0;
   /*
      First, this for loop creates the necessary amount of 
      spaces to add the new
      replacement text because the original text was smaller. 
    */
   for (str_count = src_length + (replacement_length - removal_length);
        str_count > first_index + (replacement_length - removal_length);
        str_count--) {
      *(src + str_count) =
         *(src + (str_count - (replacement_length - removal_length)));
   }
   /*
      After the necessary spaces are created, the new replacement 
      string is inserted character by character.
    */
   for (str_count = first_index; str_count < first_index + replacement_length;
        str_count++) {
      *(src + str_count) = *(replacement + replacement_count);
      replacement++;
   }
}

/*
  This function replaces a source text with a 
  replacement text, the heavy lifting is
  dont by auxillary methods, as you will see.
  We first check if parameters are valid.
  1. doc cannot be null.
  2. target cannot be null
  3. replacement cannot be null.
  The method goes in a for loop until it iterates 
  through character by character in the
  specific line of a paragraph, and iterates through all lines.
  Success is returned if parameters are valid, 
  failure is returned if they are not.
*/
int replace_text(Document * doc, const char *target, const char *replacement) {
   int paragraph_count, line_count, text_count, target_size,
      replacement_length;
   if (doc == NULL || target == NULL || replacement == NULL) {
      return FAILURE;
   }
   target_size = strlen(target), replacement_length = strlen(replacement);
   /*
      for loop goes through paragraph, line, then character by character.
    */
   for (paragraph_count = 1; paragraph_count <= doc->number_of_paragraphs;
        paragraph_count++) {
      for (line_count = 1;
           line_count <= doc->paragraphs[paragraph_count].number_of_lines;
           line_count++) {
         for (text_count = 0; text_count < MAX_STR_SIZE + 1; text_count++) {
            if (doc->paragraphs[paragraph_count].
                lines[line_count][text_count] == '\0') {
               break;
            }
            /*
               If we find a character which starts with 
               the same character as the target, we ask if
               it is the actual target using the is_target function.
             */
            if (doc->paragraphs[paragraph_count].
                lines[line_count][text_count] == *(target)) {
               if (is_target
                   (text_count, target,
                    doc->paragraphs[paragraph_count].lines[line_count])) {
                  /* 
                     If it turns out to be the right size, 
                     we ask whether the replacement size is 
                     greater or less than the target size, 
                     and call the appropriate function as 
                     described above.
                   */
                  if (target_size >= replacement_length) {
                     replace_text_with_smaller_replacement(doc->paragraphs
                                                           [paragraph_count].
                                                           lines[line_count],
                                                           replacement,
                                                           text_count,
                                                           target_size,
                                                           replacement_length);
                  } else {
                     replace_text_with_bigger_replacement(doc->paragraphs
                                                          [paragraph_count].
                                                          lines[line_count],
                                                          replacement,
                                                          text_count,
                                                          target_size,
                                                          replacement_length);
                  }
                  /*
                     Why is this necessary? There are some exception
                     cases where the text actually overlaps,
                     and a string we just replaced is re replaced
                     and it goes in a very long loop,
                     so to make sure it won't happen, text count is
                     increased as to not iterate through
                     the characters which we just added. 
                   */
                  text_count += replacement_length - 1;
               }
            }
         }
      }
   }
   return SUCCESS;
}

/*
  This function serves as the auxillary for the highlight_text method.
  It creates a reference string and deletes the source string down til
  the index of where the word to be highlighted starts. Then, the brackets
  are added and the original string is eventually returned with the brackets
  using strcat and the reference string.
*/
void manipulate_string_for_highlight(char *src,
                                     int first_index, int removal_length) {
   int str_count;
   /* Create a reference string for future use */
   char reference_string[MAX_STR_SIZE + 1] = "";
   strcpy(reference_string, src);
   /*
      All characters after first index of text are set to null characters.
    */
   for (str_count = first_index; str_count < MAX_STR_SIZE + 1; str_count++) {
      if (src[str_count] == '\0') {
         break;
      }
      src[str_count] = '\0';
   }
   /*
      First bracket added before adding new text.
    */
   strcat(src, HIGHLIGHT_START_STR);
   /*
      The first for loop here resets the string 
      post bracket to null characters,
      this is done because sometimes strcat is 
      weird and assigns characters from the
      previous line, In the next for loop, the
      insides of the brackets are filled in.
    */
   for (str_count = first_index + 1; str_count < MAX_STR_SIZE + 1;
        str_count++) {
      src[str_count] = '\0';
   }
   for (str_count = first_index + 1;
        str_count < first_index + removal_length + 1; str_count++) {
      src[str_count] = reference_string[str_count - 1];
   }
   /*
      Right bracket placed.
    */
   strcat(src, HIGHLIGHT_END_STR);
   /*
      Again, characters set to null char post bracket cuz strcat is weird.
    */
   for (str_count = first_index + removal_length + 2;
        str_count < MAX_STR_SIZE + 1; str_count++) {
      src[str_count] = '\0';
   }

   /*
      Rest of the line is copied from the reference string.
    */
   for (str_count = first_index + removal_length + 2;
        str_count < MAX_STR_SIZE + 1; str_count++) {
      src[str_count] = reference_string[str_count - 2];
   }
}

/*
  This function will highlight a specific piece of the text with [ and ]. 
  It is on a similar structure as the previous method as it iterates 
  through almost every single character.
  The function will return FAILURE if
  1. doc is NULL
  2. target is NULL
  Else, success is returned.
*/
int highlight_text(Document * doc, const char *target) {
   int paragraph_count, line_count, text_count, target_size;
   if (doc == NULL || target == NULL) {
      return FAILURE;
   }
   target_size = strlen(target);
   /*
      These for loops iterate through the document
    */
   for (paragraph_count = 1; paragraph_count <= doc->number_of_paragraphs;
        paragraph_count++) {
      for (line_count = 1;
           line_count <= doc->paragraphs[paragraph_count].number_of_lines;
           line_count++) {
         for (text_count = 0; text_count < MAX_STR_SIZE + 1; text_count++) {
            if (doc->paragraphs[paragraph_count].
                lines[line_count][text_count] == '\0') {
               break;
            }
            /* 
               If the character we found is the beginning character of the
               target, we check if it is the target.
             */
            if (doc->paragraphs[paragraph_count].
                lines[line_count][text_count] == *(target)) {
               if (is_target
                   (text_count, target,
                    doc->paragraphs[paragraph_count].lines[line_count])) {
                  /*
                     Auxillary called for heavy lifting.
                   */
                  manipulate_string_for_highlight(doc->paragraphs
                                                  [paragraph_count].lines
                                                  [line_count], text_count,
                                                  target_size);
                  /*
                     Why is this necessary? There are some exception 
                     cases where the text actually overlaps,
                     and a string we just replaced is re replaced
                     and it goes in a very long loop,
                     so to make sure it won't happen, text count
                     is increased as to not iterate through
                     the characters which we just added.
                   */
                  text_count += target_size;
               }
            }
         }
      }
   }
   return SUCCESS;
}

/*
  This function removes a specified text.
  This will return failure if:
  1. doc is null
  2. target is null
  Else it will like the previous functions go through the entire doc to find
  the text and call an auxillary to remove it.
*/
int remove_text(Document * doc, const char *target) {
   int paragraph_count, line_count, text_count, target_size;
   if (doc == NULL || target == NULL) {
      return FAILURE;
   }
   target_size = strlen(target);
   /*
      These for loops go through the entire doc down to the character.
    */
   for (paragraph_count = 1; paragraph_count <= doc->number_of_paragraphs;
        paragraph_count++) {
      for (line_count = 1;
           line_count <= doc->paragraphs[paragraph_count].number_of_lines;
           line_count++) {
         for (text_count = 0; text_count < MAX_STR_SIZE + 1; text_count++) {
            if (doc->paragraphs[paragraph_count].
                lines[line_count][text_count] == '\0') {
               break;
            }
            if (doc->paragraphs[paragraph_count].
                lines[line_count][text_count] == *(target)) {
               /*
                  Checks if the current character is the start of the target.
                */
               if (is_target
                   (text_count, target,
                    doc->paragraphs[paragraph_count].lines[line_count])) {
                  /*
                     Auxillary called to perform removal. Why have we
                     added + 1 to the target
                     size? Because of the extra space we need
                     to remove, if the thing we are
                     removing is at the end of the line, we do not add the +1.
                   */
                  remove_text_two(doc->paragraphs[paragraph_count].lines
                                  [line_count], text_count, target_size);
                  /*
                     Why is this necessary? There are some exception cases
                     where the text skips something
                     that shouldn't be skipped. So to make sure it
                     won't happen, text count is decreased
                     to not skip something we should remove. 
                   */
                  text_count--;
               }
            }
         }
      }
   }
   return SUCCESS;
}

/*
  To load a file, we check if the parameters are valid.
  1. doc cannot be NULL, failure returned.
  2. filename cannot be NULL, failure returned.
  3. If we somehow cannot open the document, failure is 
  also returned.
  
  Otherwise, we have valid stuff. First the file stream is 
  opened. Same process goes as load_document really,
  we add the first paragraph, then go in a while loop
  until fgets() reaches the end of the document, while
  adding new paragraphs when we need and new lines
  when we need. Then we close the stream. 
*/
int load_file(Document * doc, const char *filename) {
   FILE *input;
   int paragraph_count = 0, line_number = 0, length = 0;
   char line[MAX_STR_SIZE + 1];
   if (doc == NULL || filename == NULL) {
      return FAILURE;
   }

   input = fopen(filename, "r");
   if (input == NULL) {
      return FAILURE;
   }

   /*  Magic happens here, stream info exchanged. */

   add_paragraph_after(doc, paragraph_count++);
   while (fgets(line, MAX_STR_SIZE + 1, input) != NULL) {
      length = strlen(line);
      if (line[length - 1] == '\n' && length != 1) {
         line[length - 1] = '\0';
      }
      if (isspace(line[0])) {
         add_paragraph_after(doc, paragraph_count++);
         line_number = 0;
      } else {
         add_line_after(doc, paragraph_count, line_number, line);

         line_number++;
      }
   }
   fclose(input);
   return SUCCESS;
}

/*
  Again, start by checking if the parameters are valid. 
  1. doc cannot be null
  2. filename cannot be null
  3. output cannot be null
  if any of these are null, failure is returned.
  Else, the logic is simple, a new output stream is opened
  and we put the lines of the current document into the 
  target doc to be saved.
  Success is then returned.
*/
int save_document(Document * doc, const char *filename) {
   FILE *output;
   int paragraph_count = doc->number_of_paragraphs, paragraph, line;
   if (doc == NULL || filename == NULL) {
      return FAILURE;
   }
   output = fopen(filename, "w");
   if (output == NULL) {
      return FAILURE;
   }
   /*
      Iterates through the entire document line by line, new line put
      each time, and a next line is put after a line is added. When a new
      paragraph is added, an extra line is added for separation.
    */
   for (paragraph = 1; paragraph <= paragraph_count; paragraph++) {
      for (line = 1; line <= doc->paragraphs[paragraph].number_of_lines;
           line++) {
         fputs(doc->paragraphs[paragraph].lines[line], output);
         fputs("\n", output);
      }
      fputs("\n", output);
   }
   fclose(output);

   return SUCCESS;
}
