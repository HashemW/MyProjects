#include <stdio.h>
#include <string.h>
#include "document.h"
#include <assert.h>
int main() {
   Document x;
   Document *x_ptr;
   x_ptr = &x;
   assert(init_document(NULL, "document") == FAILURE);
   assert(init_document(x_ptr, NULL) == FAILURE);
   init_document(x_ptr, "document");
   assert(x_ptr->number_of_paragraphs == 0);
   assert(strcmp(x_ptr->name, "document") == 0);
   return 0;
}