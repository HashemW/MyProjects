#include <stdio.h>
#include <string.h>
#include "document.h"
#include <assert.h>
int main() {
   Document x;
      int y =0;
   int *number_of_lines = &y;
   Document *x_ptr;
   x_ptr = &x;
   add_paragraph_after(x_ptr, 0);
   add_line_after(x_ptr, 1, 0, "HELLO");
   add_line_after(x_ptr, 1, 1, "GOODBYE");
   get_number_lines_paragraph(x_ptr, 1, number_of_lines);
   printf("%d\n", *number_of_lines);
   return 0;
}