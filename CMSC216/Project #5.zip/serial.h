
void init_serial_stdio(void);
