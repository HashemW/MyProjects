#include <stdio.h>
#include <stdlib.h>
#include "event.h"
#include "calendar.h"
#include "my_memory_checker_216.h"
#include <assert.h>
#include <string.h>
/*****************************************************/
/* In this file you will provide tests for your      */
/* calendar application.  Each test should be named  */
/* test1(), test2(), etc. Each test must have a      */
/* brief description of what it is testing (this     */
/* description is important).                        */
/*                                                   */
/* You can tell whether any test failed if after     */
/* executing the students tests, you executed        */
/* "echo $?" on the command line and you get a value */
/* other than 0.  "echo $?" prints the status of     */
/* the last command executed by the shell.           */
/*                                                   */
/* Notice that main just calls test1(), test2(), etc.*/
/* and once one fails, the program eventually        */
/* return EXIT_FAILURE; otherwise EXIT_SUCCESS will  */
/* be returned.                                      */
/*****************************************************/
static int comp_minutes(const void *ptr1, const void *ptr2) {
   return ((Event *) ptr1)->start_time - ((Event *) ptr2)->start_time;
}

typedef struct desc {
   char *desc;
} Desc;
static Desc *create_info(const char *c) {
   Desc *x = malloc(sizeof(Desc));
   x->desc = malloc(strlen(c) + 1);
   strcpy(x->desc, c);
   return x;
}
static void free_info_func(void *ptr) {
   Desc *x = (Desc *) ptr;
   free(x->desc);
   free(x);
}

/* Description here: This test checks ...  
 * basic functionality like print calendar
 * and stuff, small tests, not very exhaustive.
 */
static int test1() {
   int days = 7;
   void *ptr;
   Event *event = malloc(sizeof(Event));
   const char *exblain =
      "هاذا الوقت نعمل الثورة و نبعث القوة العرب عاش الوطن و ماتو الخوناء";
   Calendar *calendar;
   ptr = &exblain;
   if (init_calendar("Spr", days, comp_minutes, NULL, &calendar) == SUCCESS) {
      assert(strcmp("Spr", calendar->name) == 0);
      assert(days == calendar->days);
   }
   add_event(calendar, "Exam", 900, 30, NULL, 1);
   add_event(calendar, "Studying", 1000, 40, NULL, 1);
   add_event(calendar, "Work", 1800, 140, NULL, 1);
   add_event(calendar, "Its demon time", 1200, 200, NULL, 7);
   add_event(calendar, "Wake up", 300, 180, NULL, 7);
   add_event(calendar, "Organize a political coup in Iraq", 1800, 1968, ptr,
             7);
   add_event(calendar, "Be invaded by a coalition of 51 countries", 2200,
             2003, NULL, 7);
   find_event(calendar, "Its demon time", &event);
   assert(strcmp((event)->name, "Its demon time") == 0);
   print_calendar(calendar, stdout, 1);
   free(event);
   return FAILURE;
}

/*
 * This is a more exhaustive series of tests for some basic functions that were
 * tested above. This is where I try to the beat the crap out of my program.
 */
static int test2() {
   int days = 5;
   Desc *free_healthcare =
      create_info("We should establish free healthcare for the people!\n");
   Desc *free_education =
      create_info("We should establish free education for the people!\n");
   Desc *invasion_of_iran =
      create_info
      ("The Iranians have broken the Algiers accord and are"
       " violating our border sovereignty, war!\n");
   Desc *tawakalna_ala_allah =
      create_info
      ("With our knowledge and experience from 8 years of war, we "
       " should launch "
       "one final decisive offensive and end the war.\n");
   Desc *invasion_of_kuwait =
      create_info
      ("We have tried diplomacy and politics, the Kuwaitis"
       " are not budging, they have worked "
       "to completely undercut our economy and steal our oil,"
       " we have no choice...\n");
   Desc *islamization_campaign =
      create_info
      ("Maybe the Ba'ath party was wrong about Islam, maybe it "
       "is our hope, not "
       " the source of backwardness, maybe it is time "
       "to return to the mosque\n.");
   Desc *endgame =
      create_info
      ("Is this the end? Is this the end of the Arab dream? "
       "The end of the Arab world? "
       "Have the Arabs lost themselves? Have we lost our "
       "rights to our history? To our past? "
       "We now look to a future that is uncertain, "
       "filled with betrayals and corruption. "
       "It is filled with immense sadness, the state of "
       "the Arabs. But we will come back! "
       "ﺏﺃﻭﻻﺩﻯ ﺏﺄﻳﺎﻣ ﺎﻠﺟﺎﻳﺍ, ﻡﺎﺘﻐﻴﺑ ﺎﻠﺸﻤﺳ"
      " ﺎﻠﻋﺮﺒﻳﺓ, ﻁﻮﻟ ﻡﺍ ﺎﻧﺍ ﻉﺎﻴﺷ ﻑﻮﻗ ﺎﻟﺪﻨﻳﺍ!");
   Event *event;
   Calendar *calendar;
   if (init_calendar
       ("Ba'ath Party Agenda", days, comp_minutes, free_info_func,
        &calendar) == SUCCESS) {
      assert(strcmp("Ba'ath Party Agenda", calendar->name) == 0);
      assert(days == calendar->days);
   }
   /* Day 1 */
   add_event(calendar, "Establish Free Healthcare", 300, 120, free_healthcare,
             1);
   add_event(calendar, "Establish Free Education", 600, 120, free_education,
             1);
   add_event(calendar, "Kill the Communists", 250, 30, NULL, 1);
   add_event(calendar, "Make some politicians have a stumble down the stairs",
             200, 30, NULL, 1);
   add_event(calendar, "Kill military officials that may perform a coup",
             1200, 10, NULL, 1);
   /* Day 2 */
   add_event(calendar, "Install sleepers and monitor the people", 1600, 30,
             NULL, 2);
   add_event(calendar, "Begin military buildup", 200, 360, NULL, 2);
   add_event(calendar, "Build Industry and sell more oil", 1200, 180, NULL,
             2);
   add_event(calendar, "Improve country infrastructure", 900, 120, NULL, 2);
   add_event(calendar, "Begin propaganda and personality cult", 2200, 60,
             NULL, 2);
   /* Day 3 */
   add_event(calendar, "Enter Period of Prosperity.", 0, 2400, NULL, 3);
   /* Day 4 */
   add_event(calendar, "Invade Iran.", 0, 1200, invasion_of_iran, 4);
   add_event(calendar, "Enter relative period of prosperity.", 1300, 120,
             NULL, 4);
   add_event(calendar,
             "Launch operation Tawakalna Ala Allah, end war with Iran.", 1200,
             50, tawakalna_ala_allah, 4);
   add_event(calendar, "Invade Kuwait.", 1991, 8, invasion_of_kuwait, 4);
   /* Day 5 */
   add_event(calendar, "Crippling Sanctions...", 200, 1200, NULL, 5);
   add_event(calendar, "Begin Islamization Campaigns...", 0, 120,
             islamization_campaign, 5);
   add_event(calendar, "Coalition of over 50 nations mobilize to invade...",
             2003, 1, NULL, 5);
   add_event(calendar, "Is this the end?", 2004, 2400, endgame, 5);
   find_event(calendar, "Is this the end?", &event);
   assert(strcmp(event->name, "Is this the end?") == 0);
   print_calendar(calendar, stdout, 1);
   printf("%s\n", ((Desc *) (event->info))->desc);
   assert(event->start_time == 2004);
   find_event(calendar, "Establish Free Healthcare", &event);
   assert(strcmp(event->name, "Establish Free Healthcare") == 0);
   assert(event->start_time == 300);
   find_event(calendar, "Enter Period of Prosperity.", &event);
   assert(strcmp(event->name, "Enter Period of Prosperity.") == 0);
   assert(event->start_time == 0);
   find_event_in_day(calendar, "Invade Iran.", 4, &event);
   assert(strcmp(event->name, "Invade Iran.") == 0);
   assert(event->start_time == 0);
   find_event_in_day(calendar, "Invade Kuwait.", 4, &event);
   assert(strcmp(event->name, "Invade Kuwait.") == 0);
   assert(event->start_time == 1991);
   find_event_in_day(calendar, "Build Industry and sell more oil", 2, &event);
   assert(strcmp(event->name, "Build Industry and sell more oil") == 0);
   assert(event->start_time == 1200);
   destroy_calendar(calendar);
   return SUCCESS;
}

/*
 * I mainly made this method to tests remove_event. Also, wanted to
 * test less days and traversal of calendar if there are empty days (after
 * removal).
 */
static int test3() {
   int days = 4;
   Calendar *calendar;
   if (init_calendar("Ataturk Agenda", days, comp_minutes, NULL, &calendar) ==
       SUCCESS) {
      assert(strcmp("Ataturk Agenda", calendar->name) == 0);
      assert(days == calendar->days);
   }
   /* Day 1 */
   add_event(calendar, "Fight the Western Powers", 0, 120, NULL, 1);
   add_event(calendar, "Kill the Kurds", 600, 120, NULL, 1);
   add_event(calendar, "Kill the Armenians", 250, 30, NULL, 1);
   add_event(calendar, "Win the war (actually quite impressively)", 200, 30,
             NULL, 1);
   /* Day 2 */
   add_event(calendar, "Repeal the Ottoman Empire (cringe)", 0, 30, NULL, 2);
   add_event(calendar, "Announce a secular republic (cringe x2)", 200, 360,
             NULL, 2);
   add_event(calendar,
             "Fight the West a couple months ago but"
             " now suck off their ideology (cringe x4)",
             1200, 180, NULL, 2);
   add_event(calendar, "Kill more Kurds and Armenians (cringe x3)", 900, 120,
             NULL, 2);
   add_event(calendar, "Seek Medical treatment", 2200, 60, NULL, 2);
   /* Day 3 */
   add_event(calendar, "Return to god?", 0, 2400, NULL, 3);
   /* Day 4 */
   add_event(calendar,
             "Die because you were an alcoholic(cringe x200)", 0, 2400,
             NULL, 4);
   remove_event(calendar, "Return to god?");
   remove_event(calendar, "Seek Medical treatment");
   print_calendar(calendar, stdout, 1);
   destroy_calendar(calendar);

   return SUCCESS;
}

/*
 * This tests if adding crappy paramters works or not, like
 * adding null and stuff.
 */
void test4() {
   Calendar *calendar;
   Event *event = malloc(sizeof(Event));
   /*adding crap parameters to init_calendar */
   assert((init_calendar(NULL, 2, NULL, NULL, &calendar) == FAILURE));
   assert((init_calendar("tsts", 0, NULL, NULL, &calendar) == FAILURE));
   assert((init_calendar("tests", 2, NULL, NULL, NULL) == FAILURE));
   assert((init_calendar(NULL, 0, NULL, NULL, NULL) == FAILURE));
   init_calendar("idk", 2, NULL, NULL, &calendar);
   /*adding crap parameters to print calendar */
   assert((print_calendar(calendar, NULL, 1) == FAILURE));
   assert((print_calendar(NULL, stdout, 1) == FAILURE));
   assert((print_calendar(NULL, NULL, 1) == FAILURE));
   /*adding crap parameters to add_event */
   assert(add_event(NULL, "hellO", 1200, 360, NULL, 1) == FAILURE);
   assert(add_event(calendar, NULL, 1200, 360, NULL, 1) == FAILURE);
   assert(add_event(calendar, "lov", -1, 360, NULL, 1) == FAILURE);
   assert(add_event(calendar, "love", 2401, 32, NULL, 1) == FAILURE);
   assert(add_event(calendar, "lob", 2300, 0, NULL, 1) == FAILURE);
   assert(add_event(calendar, "lov", 2300, 1, NULL, 2) == SUCCESS);
   assert(add_event(NULL, NULL, 2401, -1, NULL, 3) == FAILURE);
   /* find_event.... */
   assert(find_event(NULL, "lob", &event) == FAILURE);
   assert(find_event(calendar, NULL, &event) == FAILURE);
   assert(find_event(NULL, NULL, &event) == FAILURE);
   assert(find_event(calendar, "lov", NULL) == SUCCESS);
   /* find_event_in_day.... */
   assert(find_event_in_day(calendar, NULL, 2, &event) == FAILURE);
   assert(find_event_in_day(NULL, "lov", 2, &event) == FAILURE);
   assert(find_event_in_day(calendar, "lov", 3, &event) == FAILURE);
   assert(find_event_in_day(calendar, "lov", 0, &event) == FAILURE);
   assert(find_event_in_day(NULL, NULL, 0, &event) == FAILURE);
   assert(find_event_in_day(calendar, "lov", 2, NULL) == SUCCESS);
   /* remove event.. */
   assert(remove_event(NULL, "lov") == FAILURE);
   assert(remove_event(calendar, NULL) == FAILURE);
   assert(remove_event(NULL, NULL) == FAILURE);
   /* get event info.... */
   assert(get_event_info(calendar, "lov") == NULL);
   assert(get_event_info(calendar, "fake") == NULL);
   /* clear calendar.... */
   assert(clear_calendar(NULL) == FAILURE);
   /* clear day */
   assert(clear_day(NULL, 2) == FAILURE);
   assert(clear_day(calendar, 3) == FAILURE);
   assert(clear_day(calendar, 0) == FAILURE);
   /* destroy calendar */
   assert(destroy_calendar(NULL) == FAILURE);
   free(event);
   destroy_calendar(calendar);

}

/*
 * This series of tests is made to specifically look for
 * edge cases within the code to find bugs, ie removing
 * the very last and very first element of a list, etc. 
 */

void test5() {
   Calendar *calendar;
   init_calendar("Average Khomeini Supporter", 5, comp_minutes,
                 free_info_func, &calendar);
   add_event(calendar, "defend human wave attacks on reddit", 0, 20, NULL, 1);
   /* Lmao got banned from reddit */
   remove_event(calendar, "defend human wave attacks on reddit");
   add_event(calendar, "cope over iranian losses in 1988", 0, 2400, NULL, 1);
   add_event(calendar, "cope over soleimanis death (based)", 0, 2400, NULL,
             2);
   add_event(calendar,
             "larp on the internet as a persian nationalist (cringe)", 0,
             2400, NULL, 3);
   add_event(calendar,
             "work and earn 2000000000 Iranian rials (equivalent to 1 USD)",
             0, 2400, NULL, 4);
   add_event(calendar,
             "contact western news agencies and pretend "
             "to be oppressed saudi woman",
             0, 2400, NULL, 5);
   clear_calendar(calendar);
   add_event(calendar, "pretend iran did not use chemical weapons", 0, 2400,
             NULL, 1);
   add_event(calendar, "put up hezbollah pposter", 0, 2400, NULL, 5);
   clear_calendar(calendar);
   add_event(calendar, "more coping", 0, 2400, NULL, 3);
   print_calendar(calendar, stdout, 1);
   destroy_calendar(calendar);
}

/*
 * Where the tests go down.
 */
int main() {
   int result = SUCCESS;

   /***** Starting memory checking *****/
   start_memory_check();
   /***** Starting memory checking *****/
   /* I comment out some tests and not others because
    * I print the calendars, and so to make it less 
    * clunky, some tests run and others don't*/
   /*if (test1() == FAILURE) result = FAILURE; */
   /*if (test2() == FAILURE) result = FAILURE;*/
      test3();
     /* test4(); */
   /*test5();*/
   /****** Gathering memory checking info *****/
   stop_memory_check();
   /****** Gathering memory checking info *****/

   if (result == FAILURE) {
      exit(EXIT_FAILURE);
   }

   return EXIT_SUCCESS;
}
