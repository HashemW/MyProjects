/* Hashem Wahed, 117960716, hwahed */
#include <stdio.h>
#include <string.h>
#include <math.h>

#define MAX_ASSIGNMENTS 50
#define MAX_ASSIGNMENT_INFO_LENGTH 6

/*
  This method is to find the mean.
*/
double find_mean(int score_number[], int days_late[], int total_assignments,
                 int days_late_penalty) {
   int count, late_reduction;
   double sum = 0;
   /*
      So we iterate through all the assignments and do the math
      related to finding the mean. We also check if the late
      penalty goes negative, if it does it is set to 0, else
      it is kept normal. Otherwise, the assignment score minus
      the late penalty is continuously added to the variable
      sum, and eventually it is divided by the total assignments at
      the end of the method.
    */
   for (count = 0; count < total_assignments; count++) {
      if (score_number[count] - (days_late[count] * days_late_penalty) < 0) {
         late_reduction = 0;
      } else {
         late_reduction =
            score_number[count] - (days_late[count] * days_late_penalty);
      }
      sum += (late_reduction);
   }
   return sum / total_assignments;
}

/*
  This method is meant to find the standard deviation.
*/
double find_standard_deviation(int score_numbers[], int days_late[],
                               int days_late_penalty, int total_assignments,
                               double mean) {
   int count, late_reduction;
   double sum = 0, local_summation;

   /*
      So this part is similar to the previous mean method, so
      the late reduction is checked if it goes negative. Then,
      all the standard math is done to find the standard deviation
      for each assignment. The assignment minus the late
      penalty subtracts the mean, and then it is moved to the power
      of two, this is done for all assignments and added
      to the varaible sum. At the end of the method, sum is
      divided by the amount of assignments and a square root is taken.
    */
   for (count = 0; count < total_assignments; count++) {
      if (score_numbers[count] - (days_late[count] * days_late_penalty) < 0) {
         late_reduction = 0;
      } else {
         late_reduction =
            score_numbers[count] - (days_late[count] * days_late_penalty);
      }
      local_summation = (late_reduction) - mean;
      sum += pow(local_summation, 2.0);
   }

   sum /= total_assignments;
   sum = sqrt(sum);

   return sum;

}

/*
  This method finds the lowest valued assignments.
*/
int find_lowest_assignments(int number_scores[], int assignment_weights[],
                            int total_assignments) {
   int count, lowest_index = 0, lowest =
      assignment_weights[0] * number_scores[0];
   /*
      Again, all assignments are went through and this calculates the
      lowest valued assignment. The index of the lowest valued
      assignment is returned at the end, NOT the value.
    */
   for (count = 0; count < total_assignments; count++) {
      if (lowest > assignment_weights[count] * number_scores[count]) {
         lowest = assignment_weights[count] * number_scores[count];
         lowest_index = count;
      }
   }
   return lowest_index;

}

/*
  This method finds the numeric score.
*/
double find_numeric_score(int number_scores[], int weights[],
                          int daily_penalty_days[], int total_assignments,
                          int assignments_to_drop, int daily_penalty) {
   int weights_dropped[MAX_ASSIGNMENTS];
   int count, sum_of_scores = 100, late_reduction;
   double numeric_score = 0;
   /*
      Why do I make a copy of the weights dropped? Because when I call the
      find lowest value method I can alter the copied array and know which
      assignment is dropped and which is not.
    */
   for (count = 0; count < total_assignments; count++) {
      weights_dropped[count] = weights[count];
   }
   /*
      the sum_of_scores variable starts at 100 and subtracts the value of
      the assignment that is to be dropped. The lowest value is then
      changed to a very large number that cannot be reached in
      the array to be altered. We know this value cannot be reached
      because the highest value possible is 100 times 100, which is 10,000.
    */
   for (count = 0; count < assignments_to_drop; count++) {
      sum_of_scores -=
         weights_dropped[find_lowest_assignments
                         (number_scores, weights_dropped, total_assignments)];
      weights_dropped[find_lowest_assignments
                      (number_scores, weights_dropped, total_assignments)] =
         9999999;
   }
   /* 
      After setting in place the assignments to be dropped and the
      sum_of_scores, we loop through all the assignments, also seeing
      if the late reduction becomes negative as seen in earlier
      methods. We loop through the assignments and only use the weights'
      values that are not changed to account for the numeric score.
      At the end of the method we divide by the sum_of_scores and
      multiple by 100 because of decimal stuff.
    */
   for (count = 0; count < total_assignments; count++) {
      if (number_scores[count] - (daily_penalty_days[count] * daily_penalty) <
          0) {
         late_reduction = 0;
      } else {
         late_reduction =
            number_scores[count] - daily_penalty_days[count] * daily_penalty;
      }
      if (weights_dropped[count] != 9999999) {
         numeric_score +=
            (((late_reduction) * 0.01) * (weights_dropped[count]));
      }
   }

   return (numeric_score / sum_of_scores) * 100;
}

int main() {
   int penalty_per_day_late, dropped_assignments, total_assignments,
      count, local_assignment_number, weight_sum = 0;
   double mean, standard_deviation;
   /* 
      I plan to associate the assignment's number to the location of
      the array, like if the assignment number was 4, then the correct
      place to look at the amount of days late assignment 4 was turned
      in is the 4th index of the days_late_number array, the same goes
      for the rest of the arrays declared here:

      1. assignment_number pertains to the assignments in numerical order.
      2. score_number pertains to the grade achieved on said assignment.
      3. weight_number pertains to the weight that specific assignment hold.
      4. days_late_number pertains to the amount of days late that assignment
      is.
    */
   int score_number[MAX_ASSIGNMENTS] = { 0 }, weight_number[MAX_ASSIGNMENTS] = {
   0}, days_late_number[MAX_ASSIGNMENTS] = {
   0};
   char stats;
   /* 
      Here the user inputs the penalty per day, dropped assignments,
      Y or N for stats, and total assignments.
    */
   scanf(" %d %d %c", &penalty_per_day_late, &dropped_assignments, &stats);
   scanf(" %d", &total_assignments);
   /*
      Here we iterate through all the assignments and all
      the array spots are subtracted by 1 because the user will
      provide assignments in terms of 1 and 2, but we need
      a 0th index for the array, so they are all subtracted by 1.
    */
   for (count = 0; count < total_assignments; count++) {
      scanf("%d, ", &local_assignment_number);
      scanf(" %d, %d, %d", &score_number[local_assignment_number - 1],
            &weight_number[local_assignment_number - 1],
            &days_late_number[local_assignment_number - 1]);
   }

   /*
      This is here to see if all the weight adds up to 100,
      weight_sum is the sum of weights inputted.
    */
   for (count = 0; count < total_assignments; count++) {
      weight_sum += weight_number[count];
   }
   if (weight_sum != 100) {
      printf("ERROR: Invalid values provided\n");
      return 0;
   }
   /* 
     Here we print all the resulting output to the user using all
     of our methods and variables.
   */
   printf("Numeric Score: %5.4f\n",
          find_numeric_score(score_number, weight_number, days_late_number,
                             total_assignments, dropped_assignments,
                             penalty_per_day_late));
   printf("Points Penalty Per Day Late: %d\n", penalty_per_day_late);
   printf("Number of Assignments Dropped: %d\n", dropped_assignments);
   printf("Values Provided:\n");
   printf("Assignment, Score, Weight, Days Late\n");
   /*
      Prints all the assignments.
    */
   for (count = 0; count < total_assignments; count++) {
      printf("%d, %d, %d, %d\n", count + 1, score_number[count],
             weight_number[count], days_late_number[count]);
   }
   /*
      Prints statistics if necessary.
    */
   if (stats == 'Y') {
      mean =
         find_mean(score_number, days_late_number, total_assignments,
                   penalty_per_day_late);
      standard_deviation =
         find_standard_deviation(score_number, days_late_number,
                                 penalty_per_day_late, total_assignments,
                                 mean);
      printf("Mean: %5.4f, Standard Deviation: %5.4f\n", mean,
             standard_deviation);
   }

   return 0;
}
