/*
 * Hashem Wahed
 * 117960716
 * hwahed@grace.umd.edu
 */
#include <stdio.h>
#include <sys/wait.h>
#include <sysexits.h>
#include <err.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>
#include "command.h"
#include "executor.h"
#define OPEN_FLAGS (O_WRONLY | O_TRUNC | O_CREAT)
#define DEF_MODE 0664
#define MAX 80
/*static void print_tree(struct tree *t);
int execute_aux(struct tree *t, int p_input_fd, int p_output_fd);*/
/*
 * Our aux method.
 */
int execute_aux(struct tree *t, int p_input_fd, int p_output_fd) {
   pid_t pid, pid2;
   int status;
   int pipe_fd[2];
   int input, output;
   if (t->conjunction == 0) {
/*
 *  First check if the commands inputted need a child process in
 *  order to complete, the exit command requires no child, the cd
 *  command also requires no child. If the user requests to exit
 *  we exit with EXIT_SUCCESS status. With cd, we just use chdir.
 */
      if (strcmp(t->argv[0], "exit") == 0) {
         exit(EXIT_SUCCESS);
      }
      if (strcmp(t->argv[0], "cd") == 0) {
         if (chdir(t->argv[1]) != 0) {
             perror(t->argv[1]);
         }
      } else {
/*
 * Else we fork and we do exec. We always check if 
 * pid fails and do perror if it does.
 */
         pid = fork();
         if (pid < 0) {
            perror("fork error");
            exit(EX_OSERR);
         }
/*
 * wait to reap in parent process.
 */
         if (pid != 0) {
            wait(&status);
         } else {
/*
 * for input output redirection we perror if dup2,
 * open, or close fail, thus we return perror. We do
 * dup2 if input/output is not null, otherwise we do not
 * need dup2 because then we would just dup2 stdin to stdin
 * and stdout to stdout.
 */
            if (t->input != NULL) {
               input = open(t->input, O_RDONLY);
               if (input < 0) {
                  perror("open error");
                  exit(EX_OSERR);
               }
               if (dup2(input, 0) < 0) {
                  perror("dup2 error");
                  exit(EX_OSERR);
               }
               if (close(input) < 0) {
                  perror("close error");
                  exit(EX_OSERR);
               }
            }
            if (t->output != NULL) {
               output = open(t->output, OPEN_FLAGS, DEF_MODE);
               if (output < 0) {
                  perror("open error");
                  exit(EX_OSERR);
               }
               if (dup2(output, 1) < 0) {
                  perror("dup2 error");
                  exit(EX_OSERR);
               }
               if (close(output) < 0) {
                  perror("close error");
                  exit(EX_OSERR);
               }
            }
            execvp(t->argv[0], t->argv);
/*
 * If exec fails we do this crap.
 */
            fprintf(stderr, "Failed to execute %s\n", t->argv[0]);
            fflush(stdout);
            exit(EX_OSERR);
         }
      }
   }
/*
 * If this is an AND node we just execute the left side, if the
 * left side works then we also do the right side. Return 1 if
 * the left fails and return the right side.
 */
   if (t->conjunction == 1) {
      if (execute_aux(t->left, p_input_fd, p_output_fd) == 0) {
         return execute_aux(t->right, p_input_fd, p_output_fd);
      } else {
         return 1;
      }
   }
/*
 * If we are at a pipe node, this is what we need to do, we need
 * to redirect the output of the left child node to the input
 * of the pipe, and redirect the output of the pipe node to be the
 * input of the right child.
 */
   if (t->conjunction == 4) {
/*
 * First we check for ambiguous output/input redirection.
 */
      if (t->left->output != NULL) {
         printf("Ambiguous output redirect.\n");
         return 0;
      } else if (t->right->input != NULL) {
         printf("Ambiguous input redirect.\n");
         return 0;
      }
/*
 * We pipe, and if pipe fails we perror and exit.
 */
      if (pipe(pipe_fd) < 0) {
         perror("pipe error");
         exit(EX_OSERR);
      }
/*
 * fork first child.
 */
      pid = fork();
      if (pid < 0) {
            perror("fork error");
            exit(EX_OSERR);
      }
      if (pid == 0) {
/* In this child we will write, so we close the read end*/
         if (close(pipe_fd[0]) < 0) {
            perror("close error");
            exit(EX_OSERR);
         }
/*
 * Check if input is not null. If it is not, then 
 */
         if (t->input != NULL) {
           output = open(t->input, OPEN_FLAGS, DEF_MODE);
            if (output < 0) {
               perror("open error");
               exit(EX_OSERR);
            }
         }
/*
 * change output to pipe.
 */
         if (dup2(pipe_fd[1], STDOUT_FILENO) < 0) {
            perror("dup2 error");
            exit(EX_OSERR);
         }
         execute_aux(t->left, p_input_fd, output);
/*
 * close stuff after we finish.
 */ 
         close(pipe_fd[1]);
         if (t->input != NULL) {
            if (close(output) < 0) {
               perror("close error");
               exit(EX_OSERR);
            }
         } 
         exit(EXIT_SUCCESS);
      } else {
         pid2 = fork();
         if (pid2 < 0) {
            perror("fork error");
            exit(EX_OSERR);
         }
/*
 * reading pipe
 */ 
         if (pid2 == 0) {
            if (close(pipe_fd[1]) < 0) {
               perror("close error");
               exit(EX_OSERR);
            }
/*
 * Case of output redirection, if we do output redirection
 * we open the file.
 */
            if (t->output != NULL) {
               input = open(t->output, O_RDONLY);
               if (input < 0) {
                  perror("open error");
                  exit(EX_OSERR);
               }
            }
/*
 * change stdin to pipe read to get info
 */
            if (dup2(pipe_fd[0], STDIN_FILENO) < 0) {
               perror("dup2 error");
               exit(EX_OSERR);
            }
            execute_aux(t->right, input, p_output_fd);
/*
 * Close everything.
 */
            if (close(pipe_fd[0]) < 0) {
               perror("close error");
               exit(EX_OSERR);
            }
            if (t->output != NULL) {
               if (close(input) < 0) {
                  perror("close error");
                  exit(EX_OSERR);
               }
            }
            exit(EXIT_SUCCESS);
         } else {
/*
 * Close pipes in parent process.
 */
            if (close(pipe_fd[0]) < 0) {
               perror("close error");
               exit(EX_OSERR);
            }
            if (close(pipe_fd[1]) < 0) {
               perror("close error");
               exit(EX_OSERR);
            }
/* Reap processes */
            wait(NULL);
            wait(NULL);
         } 
      }
   }
/*
 * Subshell is easy it is just a shell in a shell, all we need to
 * do is change the file descriptors as needed and make recursive
 * call to left side.
 */
      if (t->conjunction == 5) {
         pid = fork();
         if (pid < 0) {
            perror("fork error");
            exit(EX_OSERR);
         }
/*
 * We do the processing of the subshell in a child process.
 */
         if (pid != 0) {
            wait(&status);
         } else {
/*
 * We check if t->input and t->output is not null, if they
 * arent then we change the file descriptors. Again if any
 * closing and opening fails we perror and exit.
 */ 
            if (t->input != NULL) {
               p_input_fd = open(t->input, O_RDONLY);
               if (dup2(p_input_fd, 0) < 0) {
                  perror("dup2 error");
                  exit(EX_OSERR);
               }
               if (p_input_fd < 0) {
                  perror("open error");
                  exit(EX_OSERR);
               }
            }
            if (t->output != NULL) {
               p_output_fd = open(t->output, OPEN_FLAGS, DEF_MODE);
               dup2(p_output_fd, 1);
               if (p_output_fd < 0) {
                  perror("open error");
                  exit(EX_OSERR);
               }
            }
            execute_aux(t->left, p_input_fd, p_output_fd);
/*
 * Close files as necessary.
 */
            if (t->input != NULL) {
                if (close(p_input_fd) < 0) {
                   perror("close error");
                   exit(EX_OSERR);
                }
            }
            if (t->output != NULL) {
                if (close(p_output_fd) < 0) {
                   perror("close error");
                   exit(EX_OSERR);
                }
            }
            exit(EXIT_SUCCESS);
         } 
      }
/*
 * Checks if everyhting exited right.
 */
   if (WIFEXITED(status) && WEXITSTATUS(status) != 0) {
      return 1;
   } else {
      return 0;
   } 
}
int execute(struct tree *t) {
   return execute_aux(t, STDIN_FILENO, STDOUT_FILENO);
}

/*static void print_tree(struct tree *t) {
   if (t != NULL) {
      print_tree(t->left);

      if (t->conjunction == NONE) {
         printf("NONE: %s, ", t->argv[0]);
      } else {
         printf("%s, ", conj[t->conjunction]);
      }
      printf("IR: %s, ", t->input);
      printf("OR: %s\n", t->output);

      print_tree(t->right);
   }
}*/

