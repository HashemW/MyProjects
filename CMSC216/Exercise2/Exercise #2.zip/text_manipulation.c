#include <stdio.h>
#include <string.h>
#include "text_manipulation.h"
static int find_first_word(const char *source) {
   int count, length;
   length = strlen(source);
   for (count = 0; count < length; count++) {
      if (*(source + count) != ' ') {
         return count;
      }
   }
   return 0;
}
static int space_check(int index, const char *source) {
   int count, length;

   length = strlen(source);
   for (count = index; count < length; count++) {
      if (*(source + count) != ' ') {
         return 0;
      }
   }
   return length - index;
}

int remove_spaces(const char *source, char *result, int *num_spaces_removed) {
   int count, string_length, first_word, incrementer = 0;

   if (source == NULL || strlen(source) == 0) {
      return FAILURE;
   }
   if (num_spaces_removed != NULL) {
      *num_spaces_removed = find_first_word(source);
   }
   string_length = strlen(source);
   first_word = find_first_word(source);
   for (count = first_word; count < string_length; count++) {
      if (*(source + count) == ' ') {
         if (space_check(count, source) != 0) {
            if (num_spaces_removed != NULL) {
               (*num_spaces_removed) += space_check(count, source);
            }
            return SUCCESS;
         }
      }
      *(result + incrementer++) = *(source + count);
   }
   return SUCCESS;
}

int center(const char *source, int width, char *result) {
   int difference, count, incrementer = 0, length;
   if (source == NULL) {
      return FAILURE;
   }
   length = strlen(source);
   if (length <= 0 || (width < length)) {
      return FAILURE;
   }

   difference = (width - length) / 2;
   for (count = 0; count < difference; count++) {
      *(result + incrementer++) = ' ';
   }
   for (count = 0; count < length; count++) {
      *(result + incrementer++) = *(source + count);
   }
   for (count = 0; count < difference; count++) {
      *(result + incrementer++) = ' ';
   }

   return SUCCESS;
}
