/* Hashem Wahed, 117960716, hwahed@grace.umd.edu */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "event.h"
#include "calendar.h"
#define MAX_STR_SIZE 80
/*
 * Here we initialize the calendar, we start by checking
 * the parameters, calendar cannot be NULL, name cannot 
 * be NULL, and days cannot be less than 1.
 */
int init_calendar(const char *name, int days,
                  int (*comp_func) (const void *ptr1, const void *ptr2),
                  void (*free_info_func) (void *ptr), Calendar ** calendar) {
   int count;
/* Failure is returned if parameters suck.*/
   if (calendar == NULL || name == NULL || days < 1) {
      return FAILURE;
   }
/*
 * Allocate memory to the calendar, if it does not 
 * work, failure is returned.
 */
   *calendar = malloc(sizeof(Calendar));
   if (*calendar == NULL) {
      return FAILURE;
   }
/*
 * Allocate memory to the calendar name, if it does
 * not work, failure is returned.
 */
   (*calendar)->name = malloc(strlen(name) + 1);
   if ((*calendar)->name == NULL) {
      return FAILURE;
   }
/* Copy the name for the calendar. */
   strcpy((*calendar)->name, name);
   /*
    * We allocate the correct amount of memory for the 
    * amount of events in the calendar, it corresponds
    * to the number of days. 
    */
   (*calendar)->events = malloc(sizeof(Event) * days);
   if ((*calendar)->events == NULL) {
      return FAILURE;
   }
   for (count = 0; count < days; count++) {
      (*calendar)->events[count] = malloc(sizeof(Event));
      if ((*calendar)->events[count] == NULL) {
         return FAILURE;
      }
      (*calendar)->events[count]->next = NULL;
   }
   (*calendar)->total_events = 0;
   /* Initializing the other non allocated values */
   (*calendar)->comp_func = comp_func;
   (*calendar)->free_info_func = free_info_func;
   (*calendar)->days = days;
   return SUCCESS;
}

/*
 * To print a calendar we first check if the parameters are valid,
 * calender and output_stream must not be NULL. We use the fprintf
 * function in order to put the info in the stream.
 */
int print_calendar(Calendar * calendar, FILE * output_stream, int print_all) {
   int day_count;
   Event *event;
   if (calendar == NULL || output_stream == NULL) {
      return FAILURE;
   }
   event = calendar->events[0];
/*
 * This information is printed only if print_all is true.
 */
   if (print_all) {
      fprintf(output_stream, "Calendar's Name: \"%s\"\n", calendar->name);
      fprintf(output_stream, "Days: %d\n", calendar->days);
      fprintf(output_stream, "Total Events: %d\n\n", calendar->total_events);
   }
/*
 * This information is printed nonetheless whether print_all is true 
 * or not.
 */
   fprintf(output_stream, "**** Events ****\n");
   if (calendar->total_events == 0) {
      return SUCCESS;
   }
   for (day_count = 1; day_count <= calendar->days; day_count++) {
      fprintf(output_stream, "Day %d\n", day_count);
      if (calendar->events[day_count - 1]->next != NULL) {
         for (event = calendar->events[day_count - 1]->next; event != NULL;
              event = event->next) {
            fprintf(output_stream,
                    "Event's Name: \"%s\", Start_time: %d, Duration: %d\n",
                    event->name, event->start_time, event->duration_minutes);
         }
      }
   }
   return SUCCESS;
}

/*
 * To add an event we check if parameters are valid.
 * calendar and name cannot be null.
 * start_time cannot be greater than 2400 or less than 0.
 * duration_minutes cannot be less than/equal to 0.
 * day cannot be greater than the number of days in the calendar.
 * Then we do a regular linked list insertion, more detail below.
 */
int add_event(Calendar * calendar, const char *name, int start_time,
              int duration_minutes, void *info, int day) {
   Event *head, *new_event;
   if (calendar == NULL || name == NULL ||
       start_time > 2400 || start_time < 0
       || duration_minutes <= 0 || day < 1 || day > calendar->days) {
      return FAILURE;
   }
   /*
   * If the event already exists we return failure.
   */
   if (find_event(calendar, name, NULL) == SUCCESS) {
      return FAILURE;
   }
   /* Start by allocating memory to the event which we will add */
   new_event = malloc(sizeof(Event));
   if (new_event == NULL) {
      return FAILURE;
   }
   /* Allocate memory to the new event's name */
   new_event->name = malloc(strlen(name) + 1);
   if (new_event->name == NULL) {
      return FAILURE;
   }
   /* Copy over all the necessary data */
   strcpy(new_event->name, name);
   new_event->start_time = start_time;
   new_event->duration_minutes = duration_minutes;
   new_event->info = info;
/*
 * This checks if we need to do an insertion at the head of the linked
 * list, if we do, we make the new event point to the thing after the
 * dummy pointer, and then make the dummy pointer point to the new 
 * event. 
 */
   if (calendar->events[day - 1]->next == NULL ||
       calendar->comp_func(calendar->events[day - 1]->next, new_event) >= 0) {
      new_event->next = calendar->events[day - 1]->next;
      calendar->events[day - 1]->next = new_event;
/*
 * And finally, this is for a tail insertion or a body insertion. I
 * use a for loop until head is null to find the place of insertion
 * using the compare function pointer.
 */
   } else {
      for (head = calendar->events[day - 1]->next; head != NULL;
           head = head->next) {
/*
 * If we have traversed the entire list and found out this event is
 * the largest event in terms of what we are comparing, we add it
 * to the end. We ask this by checking if the next node is null,
 * if it is, we just instead change the next node of the current
 * node (head) and then break out.
 */
         if (head->next == NULL) {
            head->next = new_event;
            new_event->next = NULL;
            break;
         }
/*
 * This is if we are doing a middle insertion. We check this by 
 * comparing the current event to the next node in the for loop.
 * If the next node is greater than the new event, we set the next
 * node of the new event to be the next node in the for loop,
 * and then set the next node of the local node to the new event.
 */
         if (calendar->comp_func(new_event, head->next) <= 0) {
            new_event->next = head->next;
            head->next = new_event;
            break;
         }
      }
   }
/* We add one more event to total events */
   calendar->total_events++;
   return SUCCESS;
}

/*
 * Finding the event is not too much of a complex operation, 
 * We first check if we have valid parameters, calendar and
 * name must not be null, we then check if event is NULL, if 
 * it is, nothing is done. Else, we start to loop through
 * to find the event.
 */
int find_event(Calendar * calendar, const char *name, Event ** event) {
   int day;
   Event *node;
   if (calendar == NULL || name == NULL) {
      return FAILURE;
   }
/*
 * We first loop through the days, then nest a loop going through the events
 * per day, and we compare each string one by one, if we
 * find the right event we just do a structure assignment.
 */
   for (day = 0; day < calendar->days; day++) {
/* This is necessary to see if the current day has no events */
      if (calendar->events[day] != NULL) {
         for (node = calendar->events[day]->next; node != NULL;
              node = node->next) {
            if (strcmp(node->name, name) == 0) {
               if (event == NULL) {
                  return SUCCESS;
               }
               *event = node;
               return SUCCESS;
            }
         }
      }
   }
   return FAILURE;
}

/*
 * This function is pretty much the same as the previous minus
 * one layer of nesting. We find a specific event within one
 * day, rather than the entire calendar.
 */
int find_event_in_day(Calendar * calendar, const char *name, int day,
                      Event ** event) {
   Event *node;
   /* Same rules for parameters as the previous function */
   if (calendar == NULL || name == NULL || day < 1 || day > calendar->days) {
      return FAILURE;
   }
/*
 * We first check if there are any events in the day, and then
 * go through a loop to check every node within the specific
 * day.
 */
   if (calendar->events[day - 1] != NULL) {
      for (node = calendar->events[day - 1]->next; node != NULL;
           node = node->next) {
         if (strcmp(node->name, name) == 0) {
            if (event == NULL) {
               return SUCCESS;
            }
            *event = node;
            return SUCCESS;
         }
      }
   }
   return FAILURE;
}

/*
 * Here we remove an event from the calendar, we always start
 * by checking if the parameters are valid, name and
 * calendar cannot be null. Then we go on to check if it
 * is a removal at the head, or a removal at the tail/body,
 * more detail below.
 */
int remove_event(Calendar * calendar, const char *name) {
   Event *current, *temp_ptr;
   int day = 0;
   if (calendar == NULL || name == NULL) {
      return FAILURE;
   }
/* 
 * Here we iterate through the entire calendar in order to find
 * the node to remove
 */
   for (day = 0; day < calendar->days; day++) {
/* If a day has no events, it is ignored */
      if (calendar->events[day]->next != NULL) {
/* If we are removing the head */
         if (strcmp(calendar->events[day]->next->name, name) == 0) {

/* Now we remove memory in necessary order, we clear the name of the
 * event, the event itself, and then the dummy pointer because we 
 * are removing the head.
 */
            temp_ptr = calendar->events[day]->next;
            calendar->events[day]->next = calendar->events[day]->next->next;
            if (temp_ptr->info != NULL && calendar->free_info_func != NULL) {
               calendar->free_info_func(temp_ptr);
            }
            free(temp_ptr->name);
            free(temp_ptr);
            calendar->total_events--;
            return SUCCESS;
         }
/*
 * If we are not removing the head, then we are removing something
 * in the body or the tail. So we iterate through to find it.
 */
         for (current = calendar->events[day]->next; current != NULL;
              current = current->next) {
/* If the event being removed is at the tail... */
            if (current->next == NULL && (strcmp(current->name, name) == 0)) {
               if (current->info != NULL && calendar->free_info_func != NULL) {
                  calendar->free_info_func(current);
               }
               free(current->name);
               free(current);
               calendar->total_events--;
               return SUCCESS;
/*
 * If the event we are removing is not at the tail or the head,
 * then it is in the body, and this is the difficult operation(kinda).
 * We have a temporary pointer so when we move out the node from the
 * list we can still remove it. If we find the correct event,
 * we set the temporary pointer to the event we will remove.
 * After, we make the previous event of the target point to the 
 * event after the target and we have removed the event from the
 * calendar. Then, we free the memory using the previously set
 * temporary pointer.
 */
            } else {
               if (current->next != NULL &&
                   strcmp(current->next->name, name) == 0) {
                  temp_ptr = current->next;
                  current->next = current->next->next;
                  if (temp_ptr->info != NULL &&
                      calendar->free_info_func != NULL) {
                     calendar->free_info_func(temp_ptr);
                  }
                  free(temp_ptr->name);
                  free(temp_ptr);
                  calendar->total_events--;
                  return SUCCESS;
               }
            }
         }
      }
   }
   return FAILURE;
}

/*
 * We first find the event, using the find_event function and if
 * the event exists the info is returned, else failure is returned.
 */
void *get_event_info(Calendar * calendar, const char *name) {
   Event *current;
   if (find_event(calendar, name, &current) == SUCCESS) {
      return current->info;
   }
   return NULL;
}

/*
 * This is a recursive function which clears a specific days 
 * worth of events.
 */
void clear_recursively(Calendar * calendar, Event * head) {
/*
 * This is our base case, if head->next is NULL, then the 
 * recursion stops and we free the nodes stuff.
 */
   if (head->next == NULL) {
      free(head->name);
      if (head->info != NULL && calendar->free_info_func != NULL) {
         calendar->free_info_func(head->info);
      }
      free(head);
   } else {
/*
 * After the recursive calls finish, the nodes of the 
 * event list are freed backwards.
 */
      clear_recursively(calendar, head->next);
      free(head->name);
      if (head->info != NULL && calendar->free_info_func != NULL) {
         calendar->free_info_func(head->info);
      }
      free(head);
   }
}

/*
 * If calendar is null, failure is returned. Else, we increment
 * through the days and call the clear recursive function on 
 * each day. Then the number of total events is set to 0.
 */
int clear_calendar(Calendar * calendar) {
   int day;
   if (calendar == NULL) {
      return FAILURE;
   }
   for (day = 0; day < calendar->days; day++) {
      if (calendar->events[day]->next != NULL) {
         clear_recursively(calendar, calendar->events[day]->next);
         calendar->events[day]->next = NULL;
      }
   }
   calendar->total_events = 0;
   return SUCCESS;
}

/*
 * If calendar is null or day is less than 1 failure is returned. 
 * We increment through all the events in the day and increment
 * an int count to know how many events were removed. Then we
 * call the recursive clearing function on the specific day. Then
 * we subtract the amount of elements removed.
 */
int clear_day(Calendar * calendar, int day) {
   int removed_elements = 0;
   Event *current;
   if (calendar == NULL || day < 1 || day > calendar->days) {
      return FAILURE;
   }
   for (current = calendar->events[day - 1]->next; current != NULL;
        current = current->next) {
      removed_elements++;
   }
   clear_recursively(calendar, calendar->events[day - 1]->next);
   calendar->total_events -= removed_elements;
   return SUCCESS;
}
/*
 * Destroying the calendar is a relatively simple
 * producer, we first clear the calendar and return
 * all that memory by using our previously used clear_calendar
 * function. Then we go in and clear the dummy pointers
 * by going through a for loop, Then we clear the
 * calendar members and the calendar itself.
 */
int destroy_calendar(Calendar * calendar) {
   int index;
   if (calendar == NULL) {
      return FAILURE;
   }
   clear_calendar(calendar);
/* Clearing the dummy pointers */
   for (index = 0; index < calendar->days; index++) {
      free(calendar->events[index]);
   }
   free(calendar->events);
   free(calendar->name);
   free(calendar);
   return SUCCESS;
}
