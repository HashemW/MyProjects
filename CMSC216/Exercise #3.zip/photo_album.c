#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "photo_album.h"

Photo *create_photo(int id, const char *description) {
    Photo *photo = malloc(sizeof(Photo));
    if (photo == NULL) {
       return NULL;
    }
    if (description == NULL) {
        photo->description = NULL;
        photo->id = id;
    } else { 
        photo->description = malloc(strlen(description) + 1);
        if (photo->description == NULL) {
           return NULL;
        }
        photo->id = id;
        strcpy(photo->description, description); 
    }
    return photo;
}

void print_photo(Photo *photo) {
     if (photo == NULL) {
        return;
     }
     if (photo->description == NULL) {
        printf("Photo Id: %d, Description: None\n", photo->id);
     } else {
        printf("Photo Id: %d, Description: %s\n", photo->id, photo->description);
     }
}

void destroy_photo(Photo *photo) {
     if (photo == NULL) {
        return;
     }
     free(photo->description);
     free(photo); 
}

void initialize_album(Album *album) {
     if (album == NULL) {
        return;
     }     
     album->size = 0;
}

void print_album(const Album *album) {
     int count;
     if (album == NULL) {
        return;
     }
     if (album->size == 0) {
        printf("Album has no photos.\n");
        return;
     }
     for (count = 0; count < album->size; count++) {
         print_photo(album->all_photos[count]);   
     }
}

void destroy_album(Album *album) {
     int count;
     if (album == NULL) {
        return;
     }
     for (count = 0; count < album->size; count++) {
	 destroy_photo(album->all_photos[count]);
     }
     album->size = 0;
}

void add_photo_to_album(Album *album, int id, const char *description) {
     int size;
     if (album == NULL) {
        return;
     }
     size = album->size;
     if (size < MAX_ALBUM_SIZE) {
        album->all_photos[size] = create_photo(id, description);
        album->size = size + 1;
     }
}

