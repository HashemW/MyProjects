/* This file and derivatives (C) 2012 Neil Spring and the
 * University of Maryland.  Any use, copying, or
 * distribution without permission is prohibited.
 */

struct tree;
int execute(struct tree *t);
