/* Hashem Wahed, 117960716, hwahed@grace.umd.edu */
#include <stdio.h>
#include <string.h>
#include <sysexits.h>
#include <stdlib.h>
#include <ctype.h>
#include "document.h"

/*
 * This helper function is used to purge a string and make it all null
 * characters, the process is simple, we iterate through the entire
 * string and make all characters null.
 */
static void purge_string(char *string) {
   int count;
   for (count = 0; count < MAX_STR_SIZE + 1; count++) {
      string[count] = '\0';
   }
}

/*
 * We use this helper function in order to get the strings for the
 * commands which require strings in quotations such as 
 * highlight_text or replace_text.
 * PARAMETERS:
 * 1. The index indicates where we start to look for the text.
 * 2. The src indicates the string which we will parse to find
 *    the text.
 * 3. The result is the parameter which we will copy the text
 *    without the quotation marks.
 * An int is returned that indicates the ending index of the text
 * in the src string. -1 is returned if something goes wrong.
 */
static int get_full_string(int index, const char *src, char *result) {
   int count, found_quote = 0, result_count = 0;
   /*
    * Begin iteration of line
    */
   for (count = index; count < MAX_STR_SIZE + 1; count++) {
      /*
       * When we find the first quotation mark, we instantly
       * check whether the immediate next quote is an empty
       * string, if it is, an empty string is copied into
       * result, and the proper index of the end of the
       * text is returned. Otherwise, found_quote will be
       * set to true, and will continue looking for the next
       * quotation, while it is looking for the next quotation,
       * it is copying the characters between the quotes one
       * by one. When the quote is finally found (via checking
       * the next index, count + 1, not the current index), the
       * proper index is returned indicating the end of the
       * text.
       */
      if (src[count - 1] == '\"' || found_quote) {
         if (src[count] == '\"') {
            strcpy(result, "");
            return count + 2;
         }
         found_quote = 1;
         result[result_count++] = src[count];
         if (src[count + 1] == '\"') {
            return count + 3;
         }
      }
   }
   return -1;
}

/*
 * This is a very complicated helper function. Its job is
 * to find the ending index of the command which the user inputs.
 * In other words, if a user asks for add_paragraph_after, it will
 * give the index for which the command ends. This function is
 * crucial because it helps in preventing the user from inputting
 * invalid commands as will be seen below.
 * PARAMETERS:
 * 1. command1 - This can represent any string, but is meant to 
 *    represent the command the user enters (such as add_paragraph_after).
 * 2. command2 - This is a string argument AFTER the initial user command,
 *    this argument is very helpful in parsing commands such as
 *    remove_text <string>, basically any command that has two strings.
 * 3. arg_count - This represents the amount of integer arguments which
 *    a command will have, ie paragraph numbers or line numbers, etc.
 * 4. line - This is papa. The big line which we are traversing and parsing.
 * This returns an integer of the ending position of the command/input.
 * We return the end position for another helper which checks if there is
 * anything more inputted after that index.
 * -1 is returned if anything goes wrong.
 */
static int get_end_pos_of_command(const char *command1, const char *command2,
                                  int arg_count, const char *line) {
   int count, length1, length2, found_digits = 0, count2;
   /*
    * I get these two lengths just because it makes stuff less complicated,
    * if I found a command, why iterate through the entire thing? I
    * just increment a count variable by its length to skip it.
    */
   if (command1 != NULL) {
      length1 = strlen(command1);
   }
   if (command2 != NULL) {
      length2 = strlen(command2);
   }
   /*
    * First case, if it is just a single command, like quit or
    * print_document. In this case, we iterate through and return
    * the end position in the line.
    */
   if (command2 == NULL && arg_count == 0) {
      for (count = 0; count < MAX_STR_SIZE + 1; count++) {
         if (line[count] != ' ') {
            count += length1;
            return count;
         }
      }
   }
   /*
    * Bit more complicated, this checks commands with one int argument
    * after the command name, like add_paragraph_after <arg>.
    * It uses a for loop to increment through until it finds the
    * first command, the string, after it finds the string, it
    * increments the count variable by the string length to
    * try to find the arguments afterwards, it increments after that
    * until it finds a nonspace character. When it finds an argument,
    * it asks if it is a digit, and also asks if its neighbor is a
    * digit (maybe its a double digit number or more), if it is
    * a for loop goes through to see how many digits there really
    * are and increments until it finds an endline or a space and
    * returns the index, else if there are no greater than double
    * digits, the initial count + 1 is returned to indicate
    * the end.
    */
   if (command2 == NULL && arg_count == 1) {
      for (count = 0; count < MAX_STR_SIZE + 1; count++) {
         if (line[count] != ' ') {
            if (isdigit(line[count])) {
               if (isdigit(line[count + 1])) {
                  for (count2 = count; count2 < MAX_STR_SIZE + 1; count2++) {
                     if (line[count2] == '\n' || line[count2] == ' ') {
                        return count2;
                     }
                  }
               } else {
                  return count + 1;
               }
            }
            count += length1;
         }
      }
   }
   /*
    * This is meant to target a command which has an initial
    * string command with two arguments after it, such as
    * add_line_after <arg1> <arg2>. Much similar logic is used
    * as the previous check with one argument. A for loop is
    * went through until command is found, count is increased
    * by command length, then the for loop continues until a
    * non space character is found. When it is, however this time
    * there is a variable found_digits which indicates how many
    * digits we have. When it finds a digit, found_digits is
    * increments and a for loop is went through until a space 
    * is found to indicate the end of the number. Then the
    * for loop increments again until the next number is found,
    * and when it is the end position is returned.
    */
   if (command2 == NULL && arg_count == 2) {
      for (count = 0; count < MAX_STR_SIZE + 1; count++) {
         if (line[count] != ' ') {
            if (isdigit(line[count])) {
               found_digits++;
               if (isdigit(line[count + 1])) {
                  for (count2 = count; count2 < MAX_STR_SIZE + 1; count2++) {
                     if (line[count2] == ' ') {
                        break;
                     }
                  }
                  if (found_digits == 2) {
                     return count2;
                  }
                  count = count2;
                  continue;
               } else {
                  if (found_digits == 2) {
                     return count + 1;
                  }
                  count += 1;
                  continue;
               }
            }
            count += length1;
         }
      }
   }
   /*
    * This essentially is for two commands with no argument,
    * such as highlight text or remove_text.
    * Surprisingly this is the easiest, its just simple
    * iteration through both strings until the end pos is 
    * found and that is returned.
    */
   if (arg_count == 0) {
      for (count = 0; count < MAX_STR_SIZE + 1; count++) {
         if (line[count] != ' ') {
            count += length1;
            break;
         }
      }
      for (count = count; count < MAX_STR_SIZE + 1; count++) {
         if (line[count] != ' ') {
            count += length2;
            return count;
         }
      }
   }
   return -1;
}

/*
 * This function just iterates after a specific index, and returns
 * true if there are more arguments/notable characters. False
 * if nothing notable found. 
 * By notable I mean non space, non new line, non null characters.
 */
static int has_more(int index, const char *line) {
   int count;
   for (count = index; count < MAX_STR_SIZE + 1; count++) {
      /*
       * If we get to a null character, we are pretty much
       * done and know its false.
       */
      if (line[count] == '\0') {
         return 0;
      }
      /*
       * If a notable character is found, true is returned.
       */
      if (line[count] != ' ' && line[count] != '\n') {
         return 1;
      }
   }
   return 0;
}

/*
 * Here is the horribleness...
 */
int main(int argc, char *argv[]) {
   FILE *input;
   Document doc;
   int count = 0, argument = 0, argument2 = 0, result_count = 0, index =
      0, quote_count = 0;
   int pos = -1, entries_read = 0;
   char line[MAX_STR_SIZE + 1];
   char dummy_command[MAX_STR_SIZE + 1] =
      "\0", line_argument[MAX_STR_SIZE + 1] =
      "\0", line_added[MAX_STR_SIZE + 1] = "\0";
   /* Start by initializing the document */
   init_document(&doc, "main_document");
   /* if argc is 1, then we rely on user input, we print > to start input. */
   if (argc == 1) {
      input = stdin;
      printf("> ");
      /*
       * If argc is 2 then we are getting stuff from a file of sorts. If
       * opening the file goes wrong an error message is printed and 
       * an operating system error is returned/exited.
       */
   } else if (argc == 2) {
      input = fopen(argv[1], "r");
      if (input == NULL) {
         fprintf(stderr, "%s cannot be opened.\n", argv[1]);
         return EX_OSERR;
      }
      /* If the argument count is not any of those, usage error is returned */
   } else {
      fprintf(stderr, "Usage: a.out\n");
      fprintf(stderr, "Usage: a.out <filename>\n");
      return EX_USAGE;
   }
   /*
    * Here the magic happens, the stream is gotten line by line using
    * fgets, when the function is null, the loop stops.
    */
   while (fgets(line, MAX_STR_SIZE + 1, input) != NULL) {
      /*
       * I purge all the strings which we will parse because we don't
       * any old data to stay in the strings we are using. 
       */
      purge_string(dummy_command);
      purge_string(line_argument);
      purge_string(line_added);
      pos = -1;
      result_count = 0;
      /*
       * This is is the initial sscanf (we will in many cases have 
       * specific sscanfs for each command. 
       */
      entries_read =
         sscanf(line, "%s%d%d%s", dummy_command, &argument, &argument2,
                line_argument);
      /*
       * If the initial command's first character is the # character,
       * it is a comment so we essentially ignore it. You will see
       * this if input  == stdin alot throughout this code, and this
       * tells us whether to print out > for the input. The continue
       * statements just say continue to the next line, as we are
       * done with processing this command, the continue statement
       * is used for the same reasons below.
       */
      if (dummy_command[0] == '#') {
         if (input == stdin) {
            printf("> ");
         }
         continue;
         /*
          * If the command is add_paragraph_after...
          */
      } else if (strcmp(dummy_command, "add_paragraph_after") == 0) {
         entries_read = sscanf(line, "%s%d", dummy_command, &argument);
         index = get_end_pos_of_command(dummy_command, NULL, 1, line);
         /*
          * This asks if there are more arguments after the first
          * digit (there should not be), if there are, invalid
          * command is printed and loop is continued.
          */
         if (has_more(index + 1, line)) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * If the amount of entries entered is not correct, or
          * the digit argument is negative, Invalid command is
          * printed and we continue through input.
          */
         if (entries_read != 2 || argument < 0) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * If the add_paragraph_after function fails then
          * add_paragraph_after failed is printed and loop
          * is continued, else it does nothing.
          */
         if (add_paragraph_after(&doc, argument) != SUCCESS) {
            fprintf(stdout, "add_paragraph_after failed\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * If the command is add_line_after...
          */
      } else if (strcmp(dummy_command, "add_line_after") == 0) {
         /*
          * Here we use the default sscanf. If it is the incorrect
          * number of entries, or the paragraph number is less
          * than or equal to 0, or the line number is negative,
          * invalid command is printed and we continue the loop.
          */
         if (entries_read != 4 || argument <= 0 || argument2 < 0) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         index = get_end_pos_of_command(dummy_command, NULL, 2, line);
         /*
          * This for loop checks for the existence of the * character.
          */
         for (count = index; count < MAX_STR_SIZE + 1; count++) {
            if (line[count] == '*') {
               pos = count;
               break;
            }
         }
         /*
          * If the pos value did not change, then the * character
          * does not exist, therefore invalid command is 
          * printed and loop is continued.
          */
         if (pos == -1) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         } else {
            /*
             * This increments after the * character and adds all the
             * characters to the string line_added so we know what
             * line to add. When a null character is found or an
             * enter key, the loop is done.                          
             */
            for (count = pos; count < MAX_STR_SIZE; count++) {
               if (line[count + 1] == '\0' || line[count + 1] == '\n') {
                  break;
               }
               line_added[result_count++] = line[count + 1];
            }
            /*
             * If something goes wrong with add_line_after, add_line_after
             * add_line_after is printed and loop continues, else,
             * nothing happens.
             */
            if (add_line_after(&doc, argument, argument2, line_added) !=
                SUCCESS) {

               fprintf(stdout, "add_line_after failed\n");
               if (input == stdin) {
                  printf("> ");
               }
               continue;
            }
         }
         /*
          * If the user decides to print the document...
          */
      } else if (strcmp(dummy_command, "print_document") == 0) {
         entries_read = sscanf(line, "%s", dummy_command);
         index = get_end_pos_of_command(dummy_command, NULL, 0, line);
         /*
          * If there is more input after the print_document command,
          * invalid command is printed and the loop continues.
          */
         if (has_more(index + 1, line)) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * This checks for the correct amount of arguments.
          */
         if (entries_read != 1) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * Calls print_document, if it goes wrong, print_document
          * failed is returned, else nothing happens.
          */
         if (print_document(&doc) != SUCCESS) {
            fprintf(stdout, "print_document failed\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * If the user wants to call append_line...
          */
      } else if (strcmp(dummy_command, "append_line") == 0) {
         entries_read =
            sscanf(line, "%s%d%s", dummy_command, &argument, line_argument);
         /*
          * Checks for the correct number of entries + if the argument is
          * less than or equal to 0.
          */
         if (entries_read != 3 || argument <= 0) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * This checks for the existence of the * character.
          */
         for (count = 0; count < MAX_STR_SIZE + 1; count++) {
            if (line[count] == '*') {
               pos = count;
               break;
            }
         }
         /*
          * If pos is -1, then the * character was not found,
          * invalid command is printed.
          */
         if (pos == -1) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         } else {
            /*
             * Adds all the characters after the * key to a line_added
             * string so we know what the line should be.
             */
            for (count = pos; count < MAX_STR_SIZE; count++) {
               if (line[count + 1] == '\0' || line[count + 1] == '\n') {
                  break;
               }
               line_added[result_count++] = line[count + 1];
            }
            /*
             * Finally, append_line is called. If it is unsuccessful, 
             * add_line_after failed is printed, else nothing 
             * happens.
             */
            if (append_line(&doc, argument, line_added) != SUCCESS) {

               fprintf(stdout, "add_line_after failed\n");
               if (input == stdin) {
                  printf("> ");
               }
               continue;
            }
         }
         /*
          * If the user would like to remove a line...
          */
      } else if (strcmp(dummy_command, "remove_line") == 0) {
         entries_read =
            sscanf(line, "%s%d%d", dummy_command, &argument, &argument2);
         /*
          * Finds the ending index of the command's correct layout, ie
          * remove_line 0 1. It finds the index where the command ends.
          */
         index = get_end_pos_of_command(dummy_command, NULL, 2, line);
         /*
          * This checks if there are more characters/arguments after the
          * correct number of arguments.
          */
         if (has_more(index + 1, line)) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * This checks if there are the correct amount of entries, and
          * if both arguments are equal to or less than 0, invalid
          * command is printed for any of these.
          */
         if (entries_read != 3 || argument <= 0 || argument2 <= 0) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * If remove_line goes wrong somehow, remove_line failed is
          * printed, else nothing happens.
          */
         if (remove_line(&doc, argument, argument2) != SUCCESS) {
            fprintf(stdout, "remove_line failed\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * If the user wants to call load_file...
          */
      } else if (strcmp(dummy_command, "load_file") == 0) {
         entries_read = sscanf(line, "%s%s", dummy_command, line_argument);
         /*
          * Gets the index of where the command ends after the correct
          * number of arguments.
          */
         index =
            get_end_pos_of_command(dummy_command, line_argument, 0, line);
         /*
          * If there are more characters after the correct number of
          * arguments, invalid command is returned.
          */
         if (has_more(index + 1, line)) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * If the user does not input the correct number of
          * arguments, invalid command is printed.
          */
         if (entries_read != 2) {
            printf("Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * If load_file is for some reason not successful, 
          * load_file failed is printed, else nothing
          * happens,
          */
         if (load_file(&doc, line_argument) != SUCCESS) {
            fprintf(stdout, "load_file failed\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * If replace_text is called....
          */
      } else if (strcmp(dummy_command, "replace_text") == 0) {
         entries_read =
            sscanf(line, "%s%s%s", dummy_command, line_argument, line_added);
         /*
          * This attempts to find the number of quotes, if the user inputs the
          * wrong number of quotes, invalidd command is printed.
          */
         quote_count = 0;
         index = strlen(line);
         for (count = 0; count < index; count++) {
            if (line[count] == '\"') {
               quote_count++;
            }
         }
         /*
          * If it is the incorrect number of arguments or there 
          * are not 4 quotes, invalid command is printed.
          */
         if (entries_read != 3 || quote_count != 4) {
            fprintf(stdout, "Invalid Command\n");
            quote_count = 0;
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * I purge these strings just in case they have leftover
          * data
          */
         purge_string(line_argument);
         purge_string(line_added);
         /*
          * First call to get_full_string method puts the correct
          * first string without the quotes which is requested to
          * be replaced. The argument variable is the ending index
          * of the first text, so we know where to start to find
          * the next text. 
          */
         argument = get_full_string(0, line, line_argument);
         /*
          * Now we find the text which replaces the text, and
          * that string is addded to line_added.
          */
         argument2 = get_full_string(argument, line, line_added);
         /*
          * replace_text is called and if it somehow fails, replace_text
          * failed is printed to stdout, else nothing happens.
          */
         if (replace_text(&doc, line_argument, line_added) != SUCCESS) {
            fprintf(stdout, "replace_text failed\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * If the user requests highlight_text... 
          */
      } else if (strcmp(dummy_command, "highlight_text") == 0) {
         entries_read = sscanf(line, "%s%s", dummy_command, line_argument);
         /*
          * The followwing code searches for the number of quotes.
          */
         index = strlen(line);
         quote_count = 0;
         for (count = 0; count < index; count++) {
            if (line[count] == '\"') {
               quote_count++;
            }
         }
         /*
          * If the amount of arguments is incorrect or the quote
          * count is incorrect, invalid command is printed.
          */
         if (entries_read != 2 || quote_count != 2) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * String purged just in case for leftover data.
          */
         purge_string(line_argument);
         /*
          * The string to be highlighted is found and added into
          * line_argument.
          */
         get_full_string(0, line, line_argument);
         /*
          * The text is highlighted and we are done. Or
          * maybe not, no fail command is here.
          */
         highlight_text(&doc, line_argument);
         /*
          * If the remove_text is called...
          */
      } else if (strcmp(dummy_command, "remove_text") == 0) {
         entries_read = sscanf(line, "%s%s", dummy_command, line_argument);
         /*
          * We search for the amount of quotes.
          */
         index = strlen(line);
         quote_count = 0;
         for (count = 0; count < index; count++) {
            if (line[count] == '\"') {
               quote_count++;
            }
         }
         /*
          * If the amount of entries is incorrect or
          * the quote count is incorrect, invalid command
          * is printed.
          */
         if (entries_read != 2 || quote_count != 2) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * line_argument is purged just case.
          */
         purge_string(line_argument);
         /*
          * The text is found and added into line_argument.
          */
         get_full_string(0, line, line_argument);
         /*
          * If remove_text fails somehow, remove_text failed 
          * is printed, else, nothing happens/
          */
         if (remove_text(&doc, line_argument) != SUCCESS) {
            fprintf(stdout, "remove_text failed\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
      } else if (strcmp(dummy_command, "save_document") == 0) {
         entries_read = sscanf(line, "%s%s", dummy_command, line_argument);
         index =
            get_end_pos_of_command(dummy_command, line_argument, 0, line);
         /*
          * Here we check if there are more characters after the correct
          * number of arguments. If there are, invalid command is
          * printed.
          */
         if (has_more(index + 1, line)) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * If the number of arguments is incorrect, invalid command is
          * printed.
          */
         if (entries_read != 2) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * If save_document fails somehow, remove_text failed
          * is printed, else nothing happens.
          */
         if (save_document(&doc, line_argument) != SUCCESS) {
            fprintf(stdout, "remove_text failed\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * If the user asks for reset_document...
          */
      } else if (strcmp(dummy_command, "reset_document") == 0) {
         index = get_end_pos_of_command(dummy_command, NULL, 0, line);
         /*
          * Again here we check if there are more arguments 
          * after the reset_document.
          */
         if (has_more(index + 1, line)) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * If it is the incorrect number of arguments, invalid
          * command is printed.
          */
         if (entries_read != 1) {
            fprintf(stdout, "Invalid Command.\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         /*
          * No fail message is associated with this command. It 
          * happens or it doesn't.
          */
         reset_document(&doc);
         /*
          * If the command is quit, we check if there is anything after the
          * quit command, if there is, we print invalid command and
          * continue the loop, if quit is right, then we exit
          * the program.
          */
      } else if (strcmp(dummy_command, "quit") == 0) {
         index = get_end_pos_of_command(dummy_command, NULL, 0, line);
         if (entries_read != 1 || has_more(index + 1, line)) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         exit(EXIT_SUCCESS);
         /*
          * This is the same procedure as quit but instead with exit.
          * We check if anything comes after exit, if there is
          * invalid command is printed, else we exit the program.
          */
      } else if (strcmp(dummy_command, "exit") == 0) {
         index = get_end_pos_of_command(dummy_command, NULL, 0, line);
         if (entries_read != 1 || has_more(index + 1, line)) {
            fprintf(stdout, "Invalid Command\n");
            if (input == stdin) {
               printf("> ");
            }
            continue;
         }
         exit(EXIT_SUCCESS);
         /*
          * If the user inputs a blank line.
          */
      } else if (dummy_command[0] == '\0') {

         /*
          * If any other command is asked, invalid command
          * printed.
          */
      } else {
         printf("Invalid Command\n");
      }
      /*
       * > is printed if we get all the way down here, this
       * is mainly if the user enters space/for other
       * things related to stdout.
       */
      if (input == stdin) {
         printf("> ");
      }

   }
   /*
    * The gates of hell are closed.
    */
   fclose(input);
   return 0;
}
