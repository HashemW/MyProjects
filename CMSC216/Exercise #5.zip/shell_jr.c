/* Implement your shell here */
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h> 
#include <stdlib.h>
#include <sys/wait.h>
#include <sysexits.h>
#include <err.h>
#include <string.h>
#define MAX_STR_SIZE 1024

int main() {
  pid_t pid;
  char line[MAX_STR_SIZE + 1], line2[MAX_STR_SIZE + 1], line3[MAX_STR_SIZE + 1];
  FILE *input;
  char *args[MAX_STR_SIZE + 1];
  args[0] = malloc(MAX_STR_SIZE + 1);
  args[1] = malloc(MAX_STR_SIZE + 1);
  args[2] = NULL;
  input = stdin;
  printf("shell_jr: ");
  fflush(stdout);
  while(fgets(line, MAX_STR_SIZE + 1, input) != NULL) {
      sscanf(line, "%s", line2);
      if (strcmp(line2, "exit") == 0 || strcmp(line2, "hastalavista") == 0) {
         printf("See you\n");
         exit(EXIT_SUCCESS);
      } else if (strcmp(line2, "cd") == 0) {
         sscanf(line, "%s%s", line2, line3);
         printf("shell_jr: ");
         fflush(stdout);
         chdir(line3);
         continue;
         } else {
         pid = fork();
         if (pid != 0) {
            wait(NULL);
         } else {
            sscanf(line, "%s%s", line2, line3);
            strcpy(args[0], line2);
            strcpy(args[1], line3);
            /*printf("shell_jr: ");
            fflush(stdout);*/
            execvp(line2, (char * const *)args);
            printf("Failed to execute %s\n", line2);
            fflush(stdout);
            exit(EX_OSERR);
         }
      }
      memset(line, '\0', MAX_STR_SIZE + 1);
      memset(line2, '\0', MAX_STR_SIZE + 1);
      memset(line3, '\0', MAX_STR_SIZE + 1);
      printf("shell_jr: ");
      fflush(stdout);
  }
  return 0;
} 
