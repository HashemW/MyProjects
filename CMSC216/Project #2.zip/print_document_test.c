#include <stdio.h>
#include <string.h>
#include "document.h"
int main() {
   Document example;
   Document *x_ptr;
   x_ptr = &example;

   init_document(x_ptr, "Example");

   add_paragraph_after(x_ptr, 0);
   add_line_after(x_ptr, 1, 0, "HELLO");

   add_paragraph_after(x_ptr, 1);
   
   add_line_after(x_ptr, 2, 0, "GOODBYE");

   print_document(x_ptr);
   printf("%s\n",x_ptr->paragraphs[1].lines[1]);
   return 0;
}