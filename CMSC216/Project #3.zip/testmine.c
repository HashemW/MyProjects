#include <stdio.h>
#include <stdlib.h>
#include "document.h"

int main() {
    Document x;
    load_file(&x, "doc1.txt");
    replace_text(&x, "CS", "Computer Science");
    print_document(&x);
    return 0;
}
