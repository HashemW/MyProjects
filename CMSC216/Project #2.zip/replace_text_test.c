#include <stdio.h>
#include <string.h>
#include "document.h"
int main() {
   Document doc;
   const char *one = "6.";
   const char *two = "b";
   const char *doc_name = "Loading Document ";
   int data_lines = 9;
   char data[20][MAX_STR_SIZE + 1] = {
        "tThe first course you need to take",
        "tis cmsc131.  This course will be",
        "tfollowed by cmsc132 (which is also based on Java).",
        "",
        "The next course you will take is cmsc216tttttttt.ttt",
        "This course relies on C.",
        "",
        "Ruby and Ocaml will be covered in cmsc330ttttttttt",
        "tttttttttttttttttttttttttt"
        "tttttttttttttttt"
         
   };
   
   init_document(&doc, doc_name);
   load_document(&doc, data, data_lines);
   replace_text(&doc, "t", "gay");

   print_document(&doc);
   return 0;
}