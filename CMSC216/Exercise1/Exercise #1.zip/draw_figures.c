#include <stdio.h>

/*Here are my method prototypes, these methods are described below*/
int draw_rectangle(int width, int length, char character_of_drawing);
int draw_triangle(int size, char character_of_drawing);
int valid_character(char character_of_drawing);

int main() {
   /*Variables for the sizes of the shapes chosen */
   int number_entered, width, length, size;
   /*Variable for the char the user chooses */
   char character_of_drawing;

   /*
      This loop is meant to always run. Whenever the user enters 0, the program
      breaks out of the loop.
    */
   while (1) {
      /* Prompt which asks user to enter a number */
      printf("Enter 1(rectangle), 2(triangle), 3(other), 0(quit): ");
      /* Scanner which checks input */
      scanf("%d", &number_entered);
      /*
         Below are a series of if statements which check what the
         user entered
       */
      if (number_entered == 1) {
         /*
            Prompts user to enter the width, length, 
            and character for a rectangle
          */
         printf("Enter character, width and length: ");
         scanf(" %c%d%d", &character_of_drawing, &width, &length);
         /* 
            This if statement checks to see if the draw_rectangle method
            returns true, if this is the case, the rectangle is drawn
            via the method and nothing else needs to be done, but if
            draw_rectangle is false, the user is told that he/she
            has provided invalid data, and the loop continues.
          */
         if (draw_rectangle(width, length, character_of_drawing)) {

         } else {
            printf("Invalid data provided.\n");
            continue;
         }
      } else if (number_entered == 2) {
         /*
            Pretty much the exact same process as
            the rectangle above but this is a triangle, if statement
            checks if condition is true or false, etc...
          */
         printf("Enter character and size: ");
         scanf(" %c%d", &character_of_drawing, &size);
         if (draw_triangle(size, character_of_drawing)) {

         } else {
            printf("Invalid data provided.\n");
            continue;
         }
         /* did not implement option 3 , yet ;) */
      } else if (number_entered == 3) {

         /* If number entered is 0 then we quit and break out loop */
      } else if (number_entered == 0) {
         printf("Bye Bye.\n");
         break;
         /*
            If any other value is given, invalid choice is printed
            and the loop keeps going
          */
      } else {
         printf("Invalid choice.\n");
      }
   }
   return 0;
}

/* This method just checks if the character given is valid */
int valid_character(char character_of_drawing) {
   /* A character is only valid if it is #, %, or * */
   /*
      If the character is valid, true is returned,
      else, false is returned.
    */
   if (character_of_drawing == '#' || character_of_drawing == '%'
       || character_of_drawing == '*') {
      return 1;
   } else {
      return 0;
   }
}

/* This method will draw a rectangle */
int draw_rectangle(int width, int length, char character_of_drawing) {
   /* Declaring these variables for the for loop */
   int row, col;
   /*
      Checks if character is valid and lengths are valid, if they are
      goes into a nested for loop and just prints out the character,
      rectangles are ez. :) Afterwards returns true. If any of the stuff
      is invalid false is returned.
    */
   if (valid_character(character_of_drawing) && length > 0 && width > 0) {
      for (row = 0; row < width; row++) {
         for (col = 0; col < length; col++) {
            printf("%c", character_of_drawing);
         }
         /* This is done to start a new row */
         printf("\n");
      }
      return 1;
   }
   return 0;
}

/* This method will draw a triangle (not so fun) */
int draw_triangle(int size, char character_of_drawing) {
   /*
      We start off by declaring the row and col for the for loop
      Then, the place_of_insertion is where the character will
      first be inserted into the column, which is subject to change
      in the for loop, the size_limiter limits the amount of times
      the character will be printed in the for loops, more detail
      in the for loops. Count is used for the other nested for loop
      to be limited by the size limiter, this is what we use
      to print out the characters.
    */
   int row, col, place_of_insertion = size, size_limiter = 1, count;

   /*
      Ok, first of all, if the values are valid we do this and true is
      returned at the end, else false is returned. The first
      for loop just goes up until the size, but looking at the sample
      output in the project description, the length of the entire
      triangle at the end is just the size * 2 - 1, so that will be
      the col limiter in the nested for loop. Then, spaces are
      printed until we reach the correct position to finally add
      characters, when we finally do reach that position,
      another for loop is utilised in order to print out the
      characters, this for loop is limited by the previously
      declared size_limiter. Through all of this, you
      get a triangle.
    */
   if (valid_character(character_of_drawing) && size > 0) {
      /* 
         I have this if statement because with my for loops
         only, due to a spacing error, if a user enters 1,
         nothing is printed, so I just print it manually
         for that exception case.
       */
      if (size == 1) {
         printf("*\n");
         return 1;
      }
      for (row = 0; row < size; row++) {
         for (col = 0; col < (size * 2) - 1; col++) {
            if (col == place_of_insertion) {
               for (count = 0; count < size_limiter; count++) {
                  /* characters are now printed */
                  printf("%c", character_of_drawing);
                  /*
                     This is done because we need to
                     keep the col variable in accordance
                     with which place it is at
                   */
                  col++;
               }
               /* 
                  size_limiter is increased by 2 because after every
                  row the triangle has two additional characters.
                  place_of_insertion is decremented because 
                  the characters start being printed 1 place to
                  the left after each row
                */
               size_limiter += 2;
               place_of_insertion--;
            } else {
               /* 
                  This if statement is here because if it is not
                  the output will have an extra space in the 
                  beginning, which does not look nice. Otherwise,
                  this is where spaces are printed until we reach
                  the place we can print characters
                */
               if (col != 0) {
                  printf(" ");
               }
            }
         }
         /* This is done to start a new row */
         printf("\n");
      }
      return 1;
   }
   return 0;
}
